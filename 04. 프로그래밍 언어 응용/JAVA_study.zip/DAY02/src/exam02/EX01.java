package exam02;

public class EX01 {
    public static void main(String[] args) {
        int num=11;
        if(num == 10) {
            System.out.println("10입니다");
        } else {
            System.out.println("10이 아닙니다");
        }



    }//main
}
