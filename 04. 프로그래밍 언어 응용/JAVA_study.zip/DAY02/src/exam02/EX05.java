package exam02;

public class EX05 {
    public static void main(String[] args) {
        /*int total = 0;

        total +=1 ;
        total +=2 ;
        ...
        total +=100;
    */
    }//main
}
