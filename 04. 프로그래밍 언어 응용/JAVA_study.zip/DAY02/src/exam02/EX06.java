package exam02;

public class EX06 {
    public static void main(String[] args){
        int total = 0, num = 1;
        while(num <= 100) {
            total += num;
            num++;
        }
        System.out.println(total);

    }//main
}
