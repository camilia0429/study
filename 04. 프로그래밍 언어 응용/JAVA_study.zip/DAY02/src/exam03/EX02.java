package exam03;

public class EX02 {
    public static void main(String[] args){
        int[] nums = new int[4]; // int 변수 4개 생성, 인덱스 번호 0, 1, 2, 3
        nums[0] = 10;
        nums[1] = 20;

        System.out.println(nums[0]);
        System.out.println(nums[1]);

        for(int i = 0; i <= 3; i++) {
            System.out.println(nums[i]);
        }

    }//main
}
