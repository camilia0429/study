package exam03;

public class EX01 {
    public static void main(String[] args) {
        int[] students = new int[100];
        for(int i = 0; i <= 99; i++) {
            students[i] = i+1000;
        }
    }//main
}
