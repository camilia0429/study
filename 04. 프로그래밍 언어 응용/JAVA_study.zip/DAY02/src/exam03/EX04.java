package exam03;

public class EX04 {
    public static void main(String[] args) {
        int[] nums = new int[] {10, 20, 30, 40};

        for(int i = 0; i <= 3; i++) {
            System.out.println(nums[i]);
        }
    }//main
}
