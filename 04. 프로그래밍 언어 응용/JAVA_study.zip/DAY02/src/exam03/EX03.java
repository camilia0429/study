package exam03;

public class EX03 {
    static int num;
    static double num2;
    static boolean result;

    static String str;

    public static void main(String[] args) {


        System.out.println("num=" + num + ", num2 = " + num2 + ", result = "+result+ ", str = " + str);
    }
}
