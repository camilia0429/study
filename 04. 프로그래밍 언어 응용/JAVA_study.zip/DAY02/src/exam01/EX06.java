package exam01;

public class EX06 {
    public static void main(String[] args) {
        int num = 10;
//        num = num+2;
        num+=2;
        num*=2;
        System.out.println(num);
    }
}
