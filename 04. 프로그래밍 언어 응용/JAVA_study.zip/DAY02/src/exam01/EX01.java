package exam01;

public class EX01 {
    public static void main(String[] args) {
        String str1 = "ABC";
        String str2 = "DEF";
        String str3 = str1 + str2 + 100;
        System.out.println(str3);
    }
}
