package exam01;

public class EX03 {
    public static void main(String[] args) {
        boolean result = true && true; // true
        boolean result2 = true || false; // true
        boolean result3 = !true; // false

        System.out.println("result : "+result);
        System.out.println("result : "+result2);
        System.out.println("result : "+result3);
    }
}
