package exam01;

public class EX02 {
    public static void main(String[] args) {
        int num = 10;
        boolean result1 = num > 5;
        System.out.println(result1);
    }
}
