package exam01;

public class EX05 {
    public static void main(String[] args) {
        int num = 10;

        boolean result = ++num > 10 || (num = num+20) > 20;
        System.out.println(num);
    }
}
