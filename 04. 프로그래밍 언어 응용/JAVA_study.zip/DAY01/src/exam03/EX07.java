package exam03;

public class EX07 {
    public static void main(String[] args) {
        int num=10;
//        num++;
        ++num;
        System.out.println(num);

    }
}
