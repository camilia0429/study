package exam03;

public class EX01 {
    public static void main(String[] args) {
        byte num1 = 100;
        int num2 = num1;
        System.out.println(num2);
        int result = num1 + num2;

        System.out.println(result);
    }
}
