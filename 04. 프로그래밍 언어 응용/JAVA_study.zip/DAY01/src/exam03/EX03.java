package exam03;

public class EX03 {
    public static void main(String[] args) {
        int num1 = 10;
        double num2 = 20.0;

        double result = num1+num2;
        System.out.println(result);
    }
}
