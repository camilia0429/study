package exam03;

public class EX08 {
    public static void main(String[] args) {
        int num = 10;
//        int num2 = num++;
//        int num2 = ++num;
//        int num2 = num--;
        int num2 = --num;
        System.out.println(num2);
        System.out.println(num);
    }
}
