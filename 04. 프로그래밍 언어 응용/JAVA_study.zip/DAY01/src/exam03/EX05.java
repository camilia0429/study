package exam03;

public class EX05 {
    public static void main(String[] args) {
        int num = 100;
        int num2 = -num;
        System.out.println(num2);
        int num3 = -num2;
        System.out.println(num3);
    }
}
