package exam03;

public class EX02 {
    public static void main(String[] args) {
        long num = 100L;
        double num2 = num;
        System.out.println(num2);

        float num3 = num;


    }
}
