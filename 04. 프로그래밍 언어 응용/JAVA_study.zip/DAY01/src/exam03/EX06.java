package exam03;

public class EX06 {
    public static void main(String[] args) {
        System.out.println(1%3);
        System.out.println(2%3);
        System.out.println(3%3);
        System.out.println(4%3);
        System.out.println(5%3);
        System.out.println(6%3);
        System.out.println(7%3);
        System.out.println(8%3);
        System.out.println(9%3);
    }
}
