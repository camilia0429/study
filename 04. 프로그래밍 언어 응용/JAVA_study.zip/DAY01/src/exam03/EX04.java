package exam03;

public class EX04 {
    public static void main(String[] args) {
//        int num1 = 1000;
        int num1 = 100;
        byte num2 = (byte)num1;
        System.out.println(num2);

        double num3 = 100.123;
        int num4 = (int)num3;
        System.out.println(num4);

    }
}
