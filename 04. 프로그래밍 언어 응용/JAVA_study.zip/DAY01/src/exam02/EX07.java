package exam02;

public class EX07 {
    public static void main(String[] args) {
        int num = 10;
        int num2 = 20;
        int result = num + num2;
        System.out.println(result);


    }
}
