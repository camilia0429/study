package exam02;

public class EX02 {
    public static void main(String[] args) {
        byte num = 100;
        // byte num2 = 200;
        short num3 = 200;
        // short num4 = 1000000;
    }
}
