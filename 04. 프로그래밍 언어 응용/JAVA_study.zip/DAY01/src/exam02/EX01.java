package exam02;

public class EX01 {
    public static void main(String[] args) {
        int num;
        num = 10;

        int num2 = 20;
        System.out.println(num2);

    }
}