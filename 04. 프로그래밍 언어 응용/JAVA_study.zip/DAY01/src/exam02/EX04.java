package exam02;

public class EX04 {
    public static void main(String[] args) {
        double num1 = 100.123;
        float num2 = 100.123f;

        boolean result1 = true;
        boolean result2 = false;
    }
}
