package exam02;

public class EX08 {
    public static void main(String[] args) {
        long num = 10000000000L;
    }
}
