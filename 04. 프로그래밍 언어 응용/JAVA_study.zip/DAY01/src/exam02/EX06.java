package exam02;

public class EX06 {
    public static void main(String[] args) {
        int num = 100;
        num = 200;
        System.out.println(num);

        final int NUM2 = 100;
        // NUM2 = 200;

        System.out.println(NUM2);

        final int MAX_NUM = 200;
    }
}
