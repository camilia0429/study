package exam02;

public class EX09 {
    public static void main(String[] args) {
        long num = 1_000_000_000_000L;
        
    }
}
