package exam02;

public class EX05 {
    public static void main(String[] args) {
        // 한줄설명!
        /*
        여러줄
        주석
         */
        /**
         * javadoc 인식하는 설명
         */
        // System.out.println("실행되나요?");
    }
}
