package exam02;

public class EX03 {
    public static void main(String[] args) {
        char ch = 'A';
        System.out.println(ch);
        System.out.println(ch+1);

        System.out.println('B'>'A');

        char ch2 = '가';
        System.out.println(ch2);
        System.out.println(ch2+1);

        char ch3 = 65;
        System.out.println(ch3);

        System.out.println('나'>'가');
    }
}
