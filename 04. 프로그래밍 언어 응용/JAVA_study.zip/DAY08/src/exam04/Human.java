package exam04;

public class Human {
}
