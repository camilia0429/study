package exam04;
import java.lang.*; // 컴파일러가 기본 추가


public class Ex01 extends java.lang.Object {
    public static void main(String[] args) {
//        java.lang.String str = "ABC";
        String str = "ABC";
    }
}
