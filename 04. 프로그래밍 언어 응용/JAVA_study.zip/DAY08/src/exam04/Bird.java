package exam04;

public class Bird {
}
