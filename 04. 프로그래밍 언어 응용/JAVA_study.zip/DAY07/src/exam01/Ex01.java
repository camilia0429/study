package exam01;

public class Ex01 {
    public static void main(String[] args) {
        Outer.Inner in = new Outer.Inner();
        in.method();
    }
}
