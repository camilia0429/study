package exam02;

public class A {
}
