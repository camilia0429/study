package exam02;

public interface Calculator {
    int add(int num1, int num2);
}
