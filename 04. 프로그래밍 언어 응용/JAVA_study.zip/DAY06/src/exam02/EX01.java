package exam02;

public class EX01 implements A,B{

    @Override
    public void method1() {

    }

    @Override
    public void method2() {
        System.out.println("구현 내용");
    }

    @Override
    public void method3() {

    }
}
