package exam02;

public interface C extends A,B {
    void method4();

}
