package exam02;

public interface B {
    void method2();
    void method3();
}
