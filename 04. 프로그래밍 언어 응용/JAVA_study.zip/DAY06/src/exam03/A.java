package exam03;

public class A {
    int numA = 10;
    public A() {
        System.out.println("A 생성자");
    }
}
