package exam03;

public class D extends A{
    int numD = 40;

}
