package exam06;

public interface Calculator {
    int add(int num1, int num2); //public abstract

    /*
    int minus(int num1, int num2){
        return 0;
    }  // 오류발생
    */

}
