package exam05;

public abstract class Calculator {
    int numA = 10;
    public abstract int add(int num1, int num2);

    public void commonMethod() {

    }
}
