package exam08;

public class EX01 implements A,B {
    @Override
    public void method1() {

    }

    @Override
    public void method2() {
        System.out.println("실행");

    }

    @Override
    public void method3() {

    }
}
