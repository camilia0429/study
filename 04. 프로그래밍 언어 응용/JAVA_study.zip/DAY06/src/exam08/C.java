package exam08;

public interface C extends A,B {
    void method4();
}
