package exam08;

public interface A {
    void method1();
    void method2();

}
