package exam04;

public class EX03 {
    public static void main(String[] args) {
        Human human = new Human();
        human.move();

    }
}
