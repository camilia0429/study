package exam04;

public class Dog extends Animal {
    public void move() {
        System.out.println("네발로 움직인다");
    }
    public void bark() {
        System.out.println("멍멍 짖는다");
    }
}
