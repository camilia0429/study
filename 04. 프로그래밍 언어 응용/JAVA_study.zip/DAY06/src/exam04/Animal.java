package exam04;

public class Animal {
    public void move() {
        System.out.println("움직인다");
    }
}
