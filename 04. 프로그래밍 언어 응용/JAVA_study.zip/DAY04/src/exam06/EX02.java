package exam06;

public class EX02 {
    public static void main(String[] args) {
        C c = new C();
        A a = c;

    }//main
}
