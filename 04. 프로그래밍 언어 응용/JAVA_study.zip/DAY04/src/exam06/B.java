package exam06;

public class B extends A {
    int numB = 20;

    public B() {
        super();//A()
        System.out.println("B 생성자!");
    }
}
