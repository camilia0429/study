package exam06;

public class A {
    int numA = 10;

    public A() {
        super();
        System.out.println("A 생성자!");
    }
}
