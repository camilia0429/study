package exam06;

public class C extends B {
    int numC = 30;
    public C() {
        super(); //B()
        System.out.println("C 생성자!");
    }
}
