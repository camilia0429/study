package exam06;

public class EX01 {
    public static void main(String[] args) {
        B b = new B();


        System.out.println(b.numA);

    }//main
}
