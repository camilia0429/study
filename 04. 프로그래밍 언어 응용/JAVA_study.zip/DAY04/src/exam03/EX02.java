package exam03;

public class EX02 {
    public static void main(String[] args) {
        Student.id = 1000;

        Student.staticMethod();

    }
}
