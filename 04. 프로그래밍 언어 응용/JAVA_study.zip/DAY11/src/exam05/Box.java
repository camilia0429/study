package exam05;

public class Box<T, U> {
    private T item1;
    private U item2;

    public <T> void print(T t) {

    }
}
