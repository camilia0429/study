package exam02;

public class Melon {
    public String get() {
        return "메론";
    }
}
