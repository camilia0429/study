package exam02;

public class Apple {
    public String get() {
        return "사과";
    }
}
