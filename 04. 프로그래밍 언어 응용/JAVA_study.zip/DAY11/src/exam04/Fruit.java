package exam04;

public abstract class Fruit {
    public abstract List<T> gets();
}
