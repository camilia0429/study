package exam04;

public class Apple extends Fruit {
    public String toString() {
        return "사과";
    }
}
