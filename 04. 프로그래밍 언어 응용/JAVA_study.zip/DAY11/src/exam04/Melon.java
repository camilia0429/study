package exam04;

public class Melon extends Fruit {
    public String toString() {
        return "메론";
    }
}
