package exam03;

public interface Eatable {
}
