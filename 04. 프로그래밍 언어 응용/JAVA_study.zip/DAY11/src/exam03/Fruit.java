package exam03;

public abstract class Fruit {
    public abstract String get();
}
