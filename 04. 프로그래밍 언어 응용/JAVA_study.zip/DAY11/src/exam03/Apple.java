package exam03;

public class Apple extends Fruit implements Eatable {
    public String get() {
        return "사과";
    }
}
