package exam01;

public class Ex03 {
    public static void main(String[] args) {
        String str = "ABC";
        String str2 = "ABC";

        System.out.println("str == str2 : "+(str == str2));
    }
}
