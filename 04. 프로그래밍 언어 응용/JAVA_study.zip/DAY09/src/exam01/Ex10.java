package exam01;

public class Ex10 {
    public static void main(String[] args) {
        int num1 = 10;
        System.out.println(num1 == 10);
    }
}
