package exam01;

public class Ex02 {
    public static void main(String[] args) {
        Book book = new Book("책1","저자1","출판사1");
        System.out.println(book); // book.toString()
    }
}
