package exam03;

public class Ex01 {
    public static void main(String[] args) {

        Integer num1 = new Integer(10);
        double num2 = num1.doubleValue();
        System.out.println(num2);

    }
}
