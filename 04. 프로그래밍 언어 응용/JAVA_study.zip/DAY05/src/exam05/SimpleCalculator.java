package exam05;

public class SimpleCalculator implements Calculator {
    public  int add(int num1, int num2) {
        return num1 + num2;
    }
}
