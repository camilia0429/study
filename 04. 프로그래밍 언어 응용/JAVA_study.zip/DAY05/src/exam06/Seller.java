package exam06;

public interface Seller {
    void sell();

}
