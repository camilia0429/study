package exam04;

public class B /*extends A*/ {

    /*
    public void method() {

        System.out.println("B 메서드!");
    }
    */
}
