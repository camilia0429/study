package exam04;

public final class A {
    public final void method() {
        System.out.println("A 메서드!");
    }
}
