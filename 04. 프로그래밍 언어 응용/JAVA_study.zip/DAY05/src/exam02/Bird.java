package exam02;

public class Bird extends Animal {
    public void move(){
        System.out.println("두 날개로 날아간다");
    }
}
