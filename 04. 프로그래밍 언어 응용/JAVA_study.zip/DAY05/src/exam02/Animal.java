package exam02;

public abstract class Animal {
    /*public void move() {
        System.out.println("움직인다");
    }*/
    public abstract void move();
}
