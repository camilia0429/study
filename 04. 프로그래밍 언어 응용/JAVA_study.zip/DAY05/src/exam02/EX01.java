package exam02;

public class EX01 {
    public static void main(String[] args) {
        Human human = new Human();
        human.move();

        Dog dog = new Dog();
        dog.move();

        Bird bird = new Bird();
        bird.move();
    }
}
