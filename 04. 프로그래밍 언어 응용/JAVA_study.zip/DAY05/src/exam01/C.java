package exam01;

public class C extends B {
    int numC = 30;
    public C() {
        super();
        System.out.println("C 생성자!");
    }
}
