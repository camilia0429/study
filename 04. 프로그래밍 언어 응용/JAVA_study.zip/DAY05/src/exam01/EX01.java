package exam01;

public class EX01 {
    public static void main(String[] args) {
        C c = new C();
//        A a = c;
        A a = new C();
//        B b = c;
        B b = new C();
    }//main
}
