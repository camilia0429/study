package exam01;

public class D extends A {
    int numD = 40;
}
