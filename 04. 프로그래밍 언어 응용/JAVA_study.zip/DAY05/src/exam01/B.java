package exam01;

public class B extends A {
    int numB = 20;
    public B() {
        super();
        System.out.println("B 생성자!");
    }
}
