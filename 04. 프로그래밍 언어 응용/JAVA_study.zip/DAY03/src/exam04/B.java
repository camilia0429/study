package exam04;
import exam03.*;

public class B extends A {
    public B() {
        num4 = 100;
    }
}
