package exam04;

public interface EX02 {
    public static void main(String[] args) {
        B b = new B();
        b.
    }//main
}