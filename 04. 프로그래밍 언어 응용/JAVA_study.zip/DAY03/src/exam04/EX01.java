package exam04;

// import exam03.A;
import exam03.*; // exam03 패키지에 있는 모든 클래스

public class EX01 {
    public static void main(String[] args) {
        A a = new A();
        System.out.println(a.num1);

    }//main
}
