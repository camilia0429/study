package exam03;

public class EX01 {
    public static void main(String[] args) {
        Schedule s1 = new Schedule();
        s1.year = 2023;
        s1.month = 2;
        s1.day = 31;

        s1.showInfo();
    }
}
