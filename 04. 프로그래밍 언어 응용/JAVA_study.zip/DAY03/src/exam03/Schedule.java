package exam03;

public class Schedule {
    private int year;
    private int month;
    private int day;

    void showInfo(){
        System.out.println("year = "+year+", month = "+month+", day = "+day);
    }
}
