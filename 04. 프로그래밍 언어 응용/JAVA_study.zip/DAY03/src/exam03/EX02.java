package exam03;

public class EX02 {
    public static void main(String[] args) {
        A a = new A();
        System.out.println(a.num2);

    }//main
}
