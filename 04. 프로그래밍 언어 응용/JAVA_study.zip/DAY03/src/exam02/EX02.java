package exam02;

public class EX02 {
    public static void main(String[] args){
        int result = calc(3);
        System.out.println(result);
    }//main
    static int calc(int x) {
        int y = x * 2 + 1;
        return y;
    }//calc
}
