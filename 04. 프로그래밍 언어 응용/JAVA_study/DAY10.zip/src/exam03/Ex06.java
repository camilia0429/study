package exam03;

import static exam03.Transportation.*;

public class Ex06 {
    public static void main(String[] args) {
        int totalFare = BUS.getTotalFare(10);
        System.out.println(totalFare);
    }
}
