package exam03;

import static exam03.Transportation.*;

public class Ex05 {
    public static void main(String[] args) {
//        Transportation trasns = new Transportation();
//        int fare = Transportation.BUS.getFare();
        int fare = BUS.getFare();
        System.out.println(fare);

        System.out.println(BUS);
    }
}
