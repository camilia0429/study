package exam03;

public class Ex04 {
    public static void main(String[] args) {
        System.out.println(Transportation.BUS instanceof Transportation);
    }
}
