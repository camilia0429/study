package exam03;

public class Ex01 {
    public static void main(String[] args) {
        Transportation trans = Transportation.BUS;
        System.out.println(trans==Transportation.BUS);
    }
}
