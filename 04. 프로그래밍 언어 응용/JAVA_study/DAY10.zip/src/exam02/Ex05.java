package exam02;

public class Ex05 {
    public static void main(String[] args) {

    }
}
