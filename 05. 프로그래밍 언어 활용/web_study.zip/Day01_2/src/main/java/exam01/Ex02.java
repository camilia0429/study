package exam01;

public class Ex02 {
    public static void main(String[] args) {
        Users2 users2 = new Users2("user01","1234");
        System.out.println(users2);


    }
}
