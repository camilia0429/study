package exam03;

public interface Scheduler {
    String view(int year,int month, int day);

    void print();
}
