package models.member;

public class LoginService {
    public void login(String userId, String userPw) {
        // 로그인 기능 구현 코드
    }
}
