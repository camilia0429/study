package Chapter11;

	// 클래스 명<T> (제네릭스 적용법)
public class Box<T> {
	
	// 정적인 데이터 타입
	// public int item;
	
	// 동적인 데이터 타입 (제네릭스 적용)
	public T item;
}
