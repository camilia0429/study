package Chapter11;

import java.util.ArrayList;

public class Ex06 {
	public static void main(String[] args) {
		
		ArrayList<Integer> space = new ArrayList<Integer>();
		
		for(int number=1; number<=10; number++) {
			space.add(number);
		}
		
		System.out.println("space에 저장된 데이터의 개수 = " + space.size());
		
		for(int index=0; index<space.size(); index++) {
			System.out.println(space.get(index));
		}
		
		// ArrayList 컬렉션 프레임워크를 활용한 ArrayList배열 생성 방법
		// ArrayList<Wrapper Class> 객체명 = new ArrayList<Wrapper Class>();
		// ArrayList 배열에서 특정 Index의 저장된 정수를 .get을 활용하여 출력
		
		
		//space에 저장된 데이터 중 두번째 데이터와 아홉번째 데이터를 삭제하세요
		//그리고 그 동작과정을 이해해보세요.
		
		space.remove(1);
		space.remove(8);
		
		// 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 인 상태에서
		// 2번째 인덱스에 있는 정수 2가, 삭제된 후 8번째 인덱스에 있는 정수10이 삭제됨.
		
		// 인덱스에서 삭제된 정수값에 뒷자리 정수들이 자리를 차지하여 1,3,4,5,6,7,8,9가 됨.
		
		System.out.println("space에 저장된 데이터의 개수 = " + space.size());
		
		// = System.out.println(space);
		for(int index=0; index<space.size(); index++) {
			System.out.println(space.get(index));
		}
	}
}
