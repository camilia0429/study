package Chapter11;

public class Ex01 {
	public static void main(String[] args) {
		
		int num1 = 10;
		
		//원래는 아래와 같이 안되어야 함. 하지만 Integer는 int와 매치가 되어있어서 int와 같다고 생각하면 됨.
		Integer num2 = 10;
		
		double num3 = 3.14;
		
		Double num4 = 3.14;
		
		char num5 = 'a';
		
		Character num6 = 'a';
		
		boolean num7 = false;
		
		Boolean num8 = false;
	}
}
