package Chapter11;

public class Ex04 {
	public static void main(String[] args) {
		//정수 10개를 저장하려고 함
		//저장하지 않았음에도 int(정수) 10개의 데이터를 차지함 (약 40byte)
		// ex) 10개의 정수가 아닌 4개의 정수만 저장하면 6개의 데이터가 낭비됨 (약 24byte)
		int arr[] = new int[10];
		
		
	}
}
