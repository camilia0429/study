package Chapter11;

import java.util.ArrayList;

public class Ex05 {

	public static void main(String[] args) {
		// ArrayList를 사용해서 문자열들을 저장할 수 있는 공간을 만듬
		ArrayList<String> space = new ArrayList<String>();
		space.add("A");
		space.add("B");
		System.out.println(space);
		
		space.add("D");
		System.out.println(space);
		
		space.add(2, "C");
		System.out.println(space);
		
		String str = space.get(0);
		System.out.println("0번 인덱스에 들어있는 데이터 => " + str);
		
		space.remove(0);
		System.out.println(space);
	}
}
