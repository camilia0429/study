package Chapter11;

public class Ex03 {
	public static void main(String[] args) {
	//	Box box1 = new Box();
	//	Box box2 = new Box();
		
	//	box1.item = 10;
	//	box2.item =
		
	// 제네릭스를 가지고 있는 객체를 활용.
		
		// box1 객체에 int(정수)를 적용
		// 기본데이터 타입을 사용할 수 없으므로 int는 사용할 수 없음.
		Box<Integer> box1 = new Box<Integer>();
		
		// box2 객체에 String(문자열)을 적용
		Box<String> box2 = new Box<String>();
		
		//오토 박싱이 적용된 10
		box1.item = 10;
		box2.item = "Hello World~!";
	}
}
