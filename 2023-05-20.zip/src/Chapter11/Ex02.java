package Chapter11;

public class Ex02 {
	public static void main(String[] args) {
	
		// i 는 Wrapper Class에 감싸져 있는 10을 가지고 있음. > 제네릭스를 위해 만듬
		// Integer i = new Integer(10);
		
		// Integer를 만들 때 "10"모양의 정수를 가진 문자열을 넣으면, 이를 정수 10으로 >>>변환<<<하여 감싸준다.
		// Integer i2 = new Integer("10");
		
		// = Integer i = new Integer(10); 형태만 다를 뿐, 똑같음.
		Integer i = Integer.valueOf(10);
		
		// = Integer i2 = new Integer("10");
		Integer i2 = Integer.valueOf("10");
		
		// 래핑이 된 i변수에 있는 숫자 10을 언박싱하여 num1 변수에 정수 10을 저장함.
		// int num1 = i.intValue();
		
		// num1++;
		
		// System.out.println(num1);
		
		
		
		Integer obj1 = 10;
		int num1 = obj1;
		System.out.println("num1 = " + num1);
		
		Double obj2 = 3.14;
		double num2 = obj2;
		System.out.println("num2 = " + num2);
		
		Character obj3 = 'a';
		char num3 = obj3;
		System.out.println("num3 = " + num3);
	}	
}
