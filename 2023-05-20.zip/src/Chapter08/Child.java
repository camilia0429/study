package Chapter08;

public class Child extends Parent {
	public Child() {
		super(5);
	}
}
