package Chapter08;

public class Ex02 {
	public static void main(String[] args) {
		Computer c = new Computer();
		Notebook n = new Notebook();
		
		c.showComputerInfo();
		n.showComputerInfo();
		
		
	}
}
