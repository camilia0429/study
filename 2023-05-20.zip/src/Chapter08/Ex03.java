package Chapter08;

public class Ex03 {
	public static void main(String[] args) {
		Sample s = new Sample();
		
	}
}
