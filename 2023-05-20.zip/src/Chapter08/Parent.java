package Chapter08;

public class Parent {
	public Parent(int s) {
		System.out.println("매개변수가 있는 Parent 클래스의 생성자");
	}
}
