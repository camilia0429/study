package Chapter08;

public class Student extends Person {
	
	private String schoolName;
			
	public void study() {
		System.out.println("공부한다.");	
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}
	
	
	
	
}
