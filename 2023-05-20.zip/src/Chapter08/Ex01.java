package Chapter08;

public class Ex01 {
	public static void main(String[] args) {
		Person p = new Person();
		p.setName("김철수");
		p.setAge(22);
		p.setHeight(176.1);
		
		p.say();
		p.eat();
		
		System.out.println("=====");
		
		Student s = new Student();
		s.setName("고영희");
		s.setAge(23);
		s.setHeight(160.4);
		s.setSchoolName("한국대학교");
	
		s.say();
		s.eat();
		s.study();
	}
}
