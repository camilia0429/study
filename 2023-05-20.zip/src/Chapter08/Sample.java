package Chapter08;

public class Sample {
	public void method() {
		System.out.println("쌤플 메서드");
	}
}
