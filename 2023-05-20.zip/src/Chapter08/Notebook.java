package Chapter08;

public class Notebook extends Computer {
	private double battery;
	
	

	@Override
	public void showComputerInfo() {
		System.out.println("===== [ Notebook Info ] =====");
		System.out.println("CPU = " + getCPU());
		System.out.println("GPU = " + getGPU());
		System.out.println("RAM = " + getRAM());
		System.out.println("HDD = " + getHDD());
		System.out.println("Battery = " + battery);
		System.out.println("===== ===== ===== ===== =====");
		// TODO Auto-generated method stub
		super.showComputerInfo();
	}

	public void charging() {
		System.out.println("충전");
	}
	
	public double getBattery() {
		return battery;
	}

	public void setBattery(double battery) {
		this.battery = battery;
	}


}
