package Chapter08;

public class Computer {

	private String CPU;
	private String GPU;
	private String RAM;
	private String HDD;
	
	public void showComputerInfo() {
		System.out.println("===== [ Computer Info ] =====");
		System.out.println("CPU = "+ CPU);
		System.out.println("GPU = "+ GPU);
		System.out.println("RAM =" + RAM);
		System.out.println("HDD =" + HDD);
		System.out.println("===== ===== ===== ===== ====");
	}
	
	public String getCPU() {
		return CPU;
	}

	public void setCPU(String cPU) {
		CPU = cPU;
	}

	public String getGPU() {
		return GPU;
	}

	public void setGPU(String gPU) {
		GPU = gPU;
	}

	public String getRAM() {
		return RAM;
	}

	public void setRAM(String rAM) {
		RAM = rAM;
	}

	public String getHDD() {
		return HDD;
	}

	public void setHDD(String hDD) {
		HDD = hDD;
	}

	public void powerOnOff() {
		System.out.println("전원을 켜고 끈다");
	}
	
	public void typing() {
		
		System.out.println("타이핑을 한다");
	}
	
	public void PlayGame() {
		System.out.println("게임을 한다");
	}
}
