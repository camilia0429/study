package Chapter08;

public class Dog extends Person {

}
