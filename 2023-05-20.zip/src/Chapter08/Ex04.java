package Chapter08;

public class Ex04 {
	public static void main(String[] args) {
		Parent p = new Parent(1);
		Child c = new Child();
		
		
	}
}
