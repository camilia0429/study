package Chapter05;

public class Ex10 {
	public static void main(String[] args) {
		/*
		 * if ~ else if ~ else 조건문
		 * 
		 * if(조건식) {
		 * 		소스코드1
		 * 		소스코드2
		 * 		...
		 * 		소스코드n
		 * } else if(조건식) {
		 * 		소스코드1
		 * 		소스코드2
		 * 		...
		 * 		소스코드n
		 * } ... {
		 * 
		 * } else {
		 * 		소스코드1
		 * 		소스코드2
		 * 		...	
		 * 		소스코드n
		 * }
		 */
	}
}
