package Chapter05;

import java.util.Scanner;

public class Ex03 {
	public static void main(String[] args) {
		Scanner scanf = new Scanner(System.in);
		
		
		System.out.print("아이디");
		String id = scanf.next();
		System.out.print("비밀번호");
		String pw = scanf.next();
		System.out.print("비밀번호 확인");
		String pw2 = scanf.next();
		System.out.print("이름");
		String name = scanf.next();
		System.out.print("휴대폰 번호");
		int phone = scanf.nextInt();
		
		System.out.println("아이디 " + id);
		System.out.println("비밀번호 " + pw );
		System.out.println("비밀번호 확인 " + pw2);
		System.out.println("이름 " + name);
		System.out.println("휴대폰 번호 " + phone );

	}
}

