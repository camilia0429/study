package Chapter05;

import java.util.Scanner;

public class Ex02 {
	public static void main(String[] args) {
		// 국, 영, 수 합계와 평균을 계산해라
		// 국어 : 34
		// 영어 : 41
		// 수학 : 40
		
		// 지금까지는 변수를 선언하면서 필요한 값을 직접 대입해줬음
//		int kor = 34;
//		int eng = 41;
//		int mat = 40;
		
	
		// Scanner를 사용하면 사용자가 입력한 값을 활용할 수 있으니까
		// 국, 영, 수 점수를 사용자에게 입력하도록 할 수 있음
		// 국, 영, 수 점수를 사용자에게 입력 받아 kor, eng, mat 변수에 0저장하고
		// 입력 받은 국, 영, 수의 합게와 평균을 계산하세요.
		
		Scanner scanf = new Scanner(System.in);
		
		System.out.println("< 프로그램 안내 >");
		System.out.println("이 프로그램은 국, 영, 수를 입력 받아 합계와 평균을 계산해 출력하는 프로그램입니다");
		System.out.println("화면을 클릭 후 국어점수를 입력하고 Enter 키를 누르세요");
		System.out.println("단, 국어점수는 정수만 입력해야합니다");
		System.out.println("그 후 영어점수를 입력하고 Enter 키를 누르세요");
		System.out.println("마지막으로 수학점수를 입력하고 Enter 키를 누르세요");
		
		System.out.print(" 국어점수 >>");
		int kor = scanf.nextInt();
		System.out.print(" 영어점수 >>");
		int eng = scanf.nextInt();
		System.out.print(" 수학점수 >>");
		int mat = scanf.nextInt();
		
		int total = kor + eng + mat;
		double avg = total / (double) 3;
		
		System.out.println("철수의 국어점수는 " + kor + "점 입니다");
		System.out.println("철수의 영어점수는 " + eng + "점 입니다");
		System.out.println("철수의 수학점수는 " + mat + "점 입니다");
		
		System.out.println("철수의 총점은 " + total + "점 입니다");
		System.out.println("철수의 평균은 " + avg + "점 입니다");
		
		

		
		
	}
}
