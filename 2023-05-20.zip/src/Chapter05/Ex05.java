package Chapter05;

public class Ex05 {
	public static void main(String[] args) {
		/*
		 * if 조건문
		 * 
		 * if(조건식)
		 *     소스코드
		 *     
		 * 조건식 > true, false / boolean 타입 데이터를 넣음
		 * 
		 * 컴퓨터가 if문을 만나면 조건식을 확인
		 * 조건식이 true 라면 if문 바로 밑에 있는 코드가 실행됨
		 * 조건식이 false라면 컴퓨터는 if문을 건너뜀
		 */
		
		int age = 100;

		if(age < 8)
			System.out.println("나이가 8살 미만입니다");

	}
}
