package Chapter05;

import java.util.Scanner;

public class Ex11 {
	public static void main(String[] args) {
		// 나이가 8 ~ 13살 사이라면 "초등학생" 출력
		// 나이가 14 ~ 16살 사이라면 "중학생" 출력
		// 나이가 17 ~ 19살 이라면 "고등학생" 출력
		// 나이가 20살 이상이라면 "일반인" 출력
		// 나이가 8살 미만이라면 "나이는 8살 이상부터 측정 가능합니다" 를 출력
		
		int age = 15;
		
		Scanner scanf = new Scanner(System.in);
		
		if(age < 8) {
			System.out.println("나이는 8살 이상부터 측정 가능합니다");
		} else if(age >= 8) {
			System.out.println("초등학생");
		} else if(age >= 14) {
			System.out.println("중학생");
		} else if(age >= 17) {
			System.out.println("고등학생"); 
		} else if(age >= 20) {
			System.out.println("일반인");
		}
	}
}
