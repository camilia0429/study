package Chapter05;
import java.util.Scanner;

public class Ex08 {
	public static void main(String[] args) {
		
		Scanner scanf = new Scanner(System.in);
		
		System.out.println("나이 >> ");
		int age = scanf.nextInt();
		
		if(age >= 8 && age <= 13) {
			System.out.println("초등학생");
		}
		
		if(age >= 14 && age <= 16) {
			System.out.println("중학생");
		}
		
		if(age >= 17 && age <= 19) {
			System.out.println("고등학생");
		}
	}
}
