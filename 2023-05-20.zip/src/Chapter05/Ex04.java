package Chapter05;

import java.util.Random;

public class Ex04 {
	public static void main(String[] args) {
		// 난수를 생성해야한다. 라면 Random 라이브러리를 사용하면 됨
		Random random = new Random();
		
		String[] array = {"콩나물무침", "가지볶음", "어묵볶음"};
		
		int index = random.nextInt(3);
		String data = array[index];
		
		
		System.out.println("이번주에는" + data + "반찬을 만들어 먹는걸 추천합니다~!");
		
		// 정수 난수를 생성하는 기능
		random.nextInt();
		
		// 보통 난수는 정수난수를 가장 많이 사용함
		System.out.println(random.nextInt());
		
		int randomsu = random.nextInt();
		
		// 내가 만들 프로그램은 ~21억 ~ +21억이 아니라
		// 0 ~ 9 사이의 난수만 필요함
		// 0 ~ 9 사이의 난수를 생성하는 방법은 ?
		// 합리적인 생각
		// 1. 0 ~ 9 사이의 난수를 만들어주는 기능을 사용한다. X
		// 2. % 연산자를 사용한다.+
		
		randomsu = random.nextInt() % 999;
		
		
		
		System.out.println(randomsu);
	}
}


