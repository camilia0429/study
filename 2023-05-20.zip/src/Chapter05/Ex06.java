package Chapter05;

import java.util.Scanner;

public class Ex06 {
	public static void main(String[] args) {
		// 어떤 학생의 국, 영, 수 점수를 입력 받고 합계를 계산한 후
		// 합계가 60점 이상이면 "통과"를 출력
		// 합계가 60점 미만이면 "재시험"을 출력하는 프로그램을 개발하세요.
		
		Scanner scanf = new Scanner(System.in);
		
		System.out.print("국어 점수 ->");
		int kor = scanf.nextInt();
		System.out.print("영어 점수 ->");
		int eng = scanf.nextInt();
		System.out.print("수학 점수 ->");
		int mat = scanf.nextInt();
		
		int total = kor + eng + mat;
		
		if(total >= 60) {
			System.out.println("통과");
			System.out.println("짝짝짝~ 축하합니다.");
		}	
		if(total < 60)
			System.out.println("재시험");
			
	}
}
