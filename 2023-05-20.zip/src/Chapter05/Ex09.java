package Chapter05;

import java.util.Scanner;

public class Ex09 {
	public static void main(String[] args) {
		/*
		 * if ~ else if 조건문
		 * 
		 * if(조건식) {
		 * 		소스코드1
		 * 		소스코드2
		 * 		...
		 * 		소스코드n
		 * } else if(조건식) {
		 * 		소스코드1
		 * 		소스코드2
		 * 		...
		 * 		소스코드n
		 * }
		 * 
		 */
		
		
//		int number = 1;
//		
//		if(number == 1) {
//			System.out.println("number변수의 값이 1입니다.");
//		} else if(number == 2) {
//				System.out.println("number변수의 값이 2입니다.");
//		}

		Scanner scanf = new Scanner(System.in);
		
		System.out.println("나이 >> ");
		int age = scanf.nextInt();
		
		if(age >= 8 && age <= 13) {
			System.out.println("초등학생");

		
		} else if(age >= 14 && age <= 16) {
			System.out.println("중학생");

		
		} else if(age >= 17 && age <= 19) {
			System.out.println("고등학생");
		}
	}	
}
