package Chapter05;

public class Ex13 {
	public static void main(String[] args) {
		
		int number1 = 10;
		
		// switch문과 변수의 범위
		// switch문 안에서 변수를 선언할 수 없음.
		int number2 = 20;
		switch(number1) {
			case 10:
				number2 = 20;
				
				System.out.println("number1 =" + number1);
				System.out.println("number2 =" + number2);
				break;
			case 11:
				int number3 = 30;
		}
		
		// if문과 변수의 범위
//		if(true) {
//			int number2 = 20;
			
//			System.out.println("number1 = " + number2);
//			System.out.println("number2 = " + number2);
//		}
		
//		System.out.println("number1 =" + number1);
		
		
	}
}
