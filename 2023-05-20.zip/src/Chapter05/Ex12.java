package Chapter05;

public class Ex12 {
	public static void main(String[] args) {
		/*
		 * switch 조건문
		 * 
		 * switch(값) {
		 * 		case 값1 :
		 * 			소스코드1
		 * 			소스코드2
		 * 			...
		 * 			소스코드n
		 * 			break;
		 * 		case 값2 :
		 * 			소스코드1
		 * 			소스코드2
		 * 			...
		 * 			소스코드n
		 * 			break;
		 * 		...
		 * }
		 */
		
		int number = 1;
		
		switch(number) {
			case 1: // switch로 들어온 값이 1이라면
				System.out.println("switch로 1이 들어왔습니다");
				break; // 이 case의 끝 (일반적으로 case의 끝에 넣어줌)		
			case 2:
				System.out.println("switch로 2가 들어왔습니다");
				break;
			default: // switch로 들어온 값이 case에 없을 때
				System.out.println("case1, case2만 있습니다");
				break;
		}		
	}
}
