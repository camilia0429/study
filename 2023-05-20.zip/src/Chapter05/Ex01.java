package Chapter05;

import java.util.Scanner;

public class Ex01 {
	public static void main(String[] args) {
		// Scanner 라이브러리를 사용해서 사용자에게 무언가를 입력 받는 프로그램
		Scanner scanf = new Scanner(System.in);
		
		// ~ 안에 : . ( dot/콤마 )
		int input1 = scanf.nextInt();			// 사용자에게 정수를 입력 받아야지
		double input2 = scanf.nextDouble();			// 사용자에게 실수를 입력 받아야지
		String input3 = scanf.next();				// 사용자에게 문자열을 입력 받아야지
		char input4 = scanf.next().charAt(0);		// 사용자에게 문자를 입력 받아야지
		
		System.out.println("사용자가 입력한 정수는" + input1 + "입니다");
		
		
		
		
	}
}
