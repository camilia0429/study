package Chapter05;

import java.util.Scanner;

public class Ex07 {
	public static void main(String[] args) {
		/*
		 * if ~ else 조건문
		 * 
		 * if(조건식) {
		 *		소스코드1
		 *		소스코드2
		 *		...
		 *		소스코드n
		 *} else {
		 *		소스코드1
		 *		소스코드2
		 *		...
		 *		소스코드n
		 *}
		 */
		
		// age 변수에 들어있는 값이 8이상이라면 "나이가 8살 이상입니다." 를 출력
		// age 변수에 들어있는 값이 8미만이라면 "나이가 8살 미만입니다." 를 출력하는 프로그램	
//		int age = 10;
		
//		if(age >= 8) {
//			System.out.println("나이가 8살 이상입니다.");
//		} else {
//			System.out.println("나이가 8살 미만입니다.");
//		}
		
		Scanner scanf = new Scanner(System.in);
		
		System.out.print("국어 점수 ->");
		int kor = scanf.nextInt();
		System.out.print("영어 점수 ->");
		int eng = scanf.nextInt();
		System.out.print("수학 점수 ->");
		int mat = scanf.nextInt();
		
		int total = kor + eng + mat;
		
		if(total >= 60) {
			System.out.println("통과");
			System.out.println("짝짝짝~ 축하합니다.");
			
		}	 else {
			System.out.println("재시험");
		}
	}
}
