package Chapter10;


	// 추상 클래스 (활용 거의 X, 인터페이스 활용)
	// 상속 관계에서 부모클래스임
public abstract class Sample {
	private int value;
	
	// 일반 메서드
	public void func1() {
		System.out.println("일반적인 메서드");
	}
	
	// 추상 메서드
	public abstract void func2();
}
