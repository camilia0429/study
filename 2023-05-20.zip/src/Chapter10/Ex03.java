package Chapter10;

public class Ex03 {
	public static void main(String[] args) {
//		Sample s = new Sample();
//		
//		s.func1();
//		s.func2();
	
		Example e = new Example();
		
		e.func1();
		e.func2();
		
		
		//부모클래스 객체 = new 자식클래스();
		Sample s = new Example();
		s.func1();
		s.func2();
	}
}
