package Chapter10;

public interface 개발계획 {
	public int 로그인(String email, String password); 
		
	
}
