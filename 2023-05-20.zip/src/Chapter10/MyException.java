package Chapter10;

public class MyException extends RuntimeException {

}
