package Chapter10;

public class Ex02 {
	public static void main(String[] args) {
		System.out.println(MakeCalculatorPlan.value);
	}
}
