package Chapter10;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Ex05 {
	public static void main(String[] args) {
		Scanner scanf = new Scanner(System.in);
		
		int[] arr = {3, 2, 1};
		
		System.out.print("인덱스 번호 >>");
		
		try {
			int index = scanf.nextInt();
			
			System.out.println("arr[" + index + "] = " + arr[index]);
		}	catch (InputMismatchException | ArrayIndexOutOfBoundsException e) {
				System.out.println("인덱스 번호를 잘못 입력하셨습니다.");
		} finally {
			// 예외가 발생하든 발생하지 않든 항상 실행되야하는 코드
			System.out.println("finally의 코드");
		}
	}
}

	

