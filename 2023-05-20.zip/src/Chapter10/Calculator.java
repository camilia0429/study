package Chapter10;

public class Calculator implements MakeCalculatorPlan {

	@Override
	public int add(int num1, int num2) {
		// TODO Auto-generated method stub
		return num1 + num2;
	}

	@Override
	public int minus(int su1, int su2) {
		// TODO Auto-generated method stub
		return su1 - su2;
	}

	@Override
	public int mul(int num1, int num2) {
		// TODO Auto-generated method stub
		return num1 * num2;
	}

	@Override
	public int div(int num1, int num2) throws ArithmeticException {
		System.out.println("div 메서드 호출됨");
		System.out.println("분모 = " + num1);
		System.out.println("분자 = " + num2);
		
			int result = num2 / num1;
			
			System.out.println(num2 + " / " + num1 + " = " + result);
		
			return 0;
	}	
}

