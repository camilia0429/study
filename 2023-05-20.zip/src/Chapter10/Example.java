package Chapter10;

// 추상 클래스를 구현하기 위해서는 extends 를 사용함.
public class Example extends Sample {

	// 계획을 구현했으므로 객체 생성이 가능해짐.
	@Override
	public void func2() {
		System.out.println("func2 메서드를 구현한 Example 클래스");
	}
	

}
