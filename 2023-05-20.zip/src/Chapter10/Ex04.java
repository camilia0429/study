package Chapter10;

import java.util.Scanner;

public class Ex04 {
	public static void main(String[] args) {
		Scanner scanf = new Scanner(System.in);
		
		System.out.print("첫번째 수 입력 >>");
		int su1 = scanf.nextInt();
		
		System.out.print("두번째 수 입력 >>");
		int su2 = scanf.nextInt();

		try {
			int result = su1 / su2;
			
			System.out.println(su1 + " / " + su2 + " = " + result);
		} catch(ArithmeticException e) {
			System.out.println("분모는 0일 수 없습니다.");
			
		}
			
	}
}
