package Chapter10;

public class Ex07 {
	public static void main(String[] args) {
		int su1 = 0;
		int su2 = 7;
		
		Calculator c = new Calculator();
		try {
			int result = c.div(su1, su2);

		System.out.println("결과 =" + result + " 입니다.");
	} catch(ArithmeticException e) {
		System.out.println("분모는 0일 수 없습니다.");
		}
	}
}