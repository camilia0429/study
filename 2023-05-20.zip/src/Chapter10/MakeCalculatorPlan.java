package Chapter10;

public interface MakeCalculatorPlan {
	private static final int value = 10;
	
	public abstract int add(int num1, int num2);
	
	public abstract int minus(int su1, int su2);
	
	public abstract int mul(int num1, int num2);
	
	public abstract int div(int num1, int num2);
	
}
