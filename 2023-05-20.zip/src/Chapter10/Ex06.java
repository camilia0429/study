package Chapter10;

public class Ex06 {
	public static void main(String[] args) {
		try {
			// 예외가 발생할 가능성이 있는 코드들
			
			throw new MyException();
	
		} catch(MyException e) {
			System.out.println("내가 만든 예외가 발생했음");
		}
	}
}
