package Chapter10;

public interface SampleInterface {

	// abstract 메서드
	
	
	
	//public abstract 반환타입 메서드 명(매개변수, 매개변수);
	//abstract = 추상적인, 추상의 (추상 메서드)
	public abstract 반환타입 메서드 명(매개변수, 매개변수);
}
