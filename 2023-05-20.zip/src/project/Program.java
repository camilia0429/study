package project;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/*
 * 회원 가입, 로그인, 회원 정보 수정, 회원 탈퇴가 가능한 프로그램
 * 	회원가입 - 회원 정보를 저장
 * 	로그인 - 저장된 회원 정보 중에서 사용자가 입력한 아이디와 비밀번호가 일치하는 계정을 찾는 것
 * 	회원 정보 수정 - 저장된 회원 정보를 새로운 정보로 바꾸는 것
 * 	회원 탈퇴 - 저장된 회원 정보를 삭제하는 것 
 */

public class Program {
	public static void main(String[] args) {
		Scanner scanf = new Scanner(System.in);
		List<Member> memberList = new ArrayList<>();
		
		while(true) {
			System.out.println("<< 프로젝트 >>");
			System.out.println("1. 회원가입");
			System.out.println("2. 로그인");
			System.out.println("3. 프로그램 종료");
			System.out.println("메뉴 번호 입력 >> ");
			int menu = scanf.nextInt();
			
		if(menu == 1) {
			// 회원 가입 구현
			// 1. 사용자에게 회원 정보(아이디, 비밀번호, 닉네임)를 입력 받는다. (Scanner import 사용)
			// 2. 회원 정보를 저장한다. (class 생성 후 id, pw, nickname Getter Setter 생성 및 생성자 생성
			//           > List 활용하여 id, pw, nickname을 ArrayList로 묶음.
			System.out.println("<< 회원가입 페이지 >>");
			
			System.out.print("아이디를 입력 하세요. =>");
			String id = scanf.next();
			
			System.out.print("비밀번호를 입력 하세요. =>");
			String pw = scanf.next();
			
			System.out.print("닉네임을 입력 하세요. =>");
			String nickname = scanf.next();
			
			Member member = new Member(id, pw, nickname);
			memberList.add(member);
			
			System.out.println("<< ! 회원가입 완료 ! >>");
	} else if(menu == 2) {
		// 로그인 기능 구현 
		// 1. 아이디, 비밀번호를 입력 받는다.
		// 2. 저장된 회원 정보의 처음부터 끝까지 차례대로 접근하면서
		// 	  사용자가 입력한 아이디와 비밀번호가 일치하는 계정이 있는지 찾는다.
		// 3. 저장된 회원 정보 중에서 사용자가 입력한 아이디와 비밀번호가 일치하는 계정이 있으면 "로그인 성공"을 출력
		// 4. 저장된 회원 정보 중에서 사용자가 입력한 아이디와 비밀번호가 일치하는 계정이 없으면 "로그인 실패"를 출력
			System.out.println("<< 로그인 페이지 >>");
		
			System.out.print("아이디를 입력 하세요. =>");
				String id = scanf.next();
		
			System.out.print("비밀번호를 입력 하세요. =>");
				String pw = scanf.next();
				
			boolean isExist = false;

			for(int i=0; i<memberList.size(); i++) {
				Member nthMember = memberList.get(i);
				String nthMemberId = nthMember.getId();
				String nthMemberPw = nthMember.getPw();
			
			if(nthMemberId.equals(id) && nthMemberPw.equals(pw)) {
				isExist = true;
			} else {

			}
		}
			if(isExist) {
				System.out.println("로그인 성공");
			} else {
				System.out.println("로그인 실패");
			}
			
				System.out.println("<< ! 로그인 완료 ! >>");
		} else if(menu == 3) {
				System.out.println("프로그램을 종료합니다.");
			
		break;
			}
		}
	}
}