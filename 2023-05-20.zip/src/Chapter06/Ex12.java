package Chapter06;

public class Ex12 {
	public static void main(String[] args) {
		String str1 = "apple";
		String str2 = "banana";
		
		System.out.println(str1 == str2);
		
		//str1이 참조하고 있는 문자열과 str2가 참조하고 있는 문자열이 같나요?
		System.out.println(str1.equals(str2));
		
		str1 = "우리는 지금 자바 기초 수업을 듣고 있습니다. 그렇지만 지금까지는 프로그램 입문을 했고 이제부터는 자바 기초 과정을 나갑니다";
		System.out.println(str1.length());
	
		//str1이 가지고 있는 문자열(참조하고 있는)에서 첫번째 문자를 사용하고 싶다. 그럴 때는 str1.charAt(인덱스번호) 를 사용
		
		System.out.println(str1.charAt(0));
		
		char ch = str1.charAt(0);
		
	}
}
