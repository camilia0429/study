package Chapter06;

public class Ex01 {
	public static void main(String[] args) {
		/*
		 * while 반복문
		 * 
		 * while(조건식) {
		 * 		소스코드1
		 * 		소스코드2
		 * 		...
		 * 		소스코드n
		 * }
		 */
		
		// count변수가 1부터
		int count = 1;
		 
		// 5이하일 동안
		while(count <= 5) {
			System.out.println("Hello World~!");
	
			// 하나씩 증가하면서 코드를 반복적으로 실행시킴
			count++;
		}
	}
}
