package Chapter06;

import java.util.Random;

public class Ex07 {
	public static void main(String[] args) {
		// Random 라이브러리를 사용해서 1 ~ 6까지 있는 정육면제 추사위를 4번 굴리는 프로그램을 개발하세요
		// 주사위를 굴릴 대마다 굴려서 나온 숫자를 출력하면 됩니다.
		
		Random random = new Random();
		
		int count = 1;
		
		while(count <= 4) {
			
			int dice = random.nextInt(6) +1;
			System.out.println("dice =>" + dice);
			
			count++;
			
			System.out.println("count = " + count);
			System.out.println("dice = " + dice);
		}
	

		
		
		
	}
}
