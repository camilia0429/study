package Chapter06;

public class Ex03 {
	public static void main(String[] args) {
		//아래 코드를 반복문을 사용한 코드로 바꾸세요
		
		int num = 1;
			while(num <= 10) {
				System.out.println(num);
				num++;
			}
	}
}
