package Chapter06;

import java.util.Random;

public class Ex08 {
	public static void main(String[] args) {
		
		Random random = new Random();

		int dice = 7;
	
		while(true) {

			//주사위를 굴린다
			dice = random.nextInt(6) + 1;
			
			System.out.println("dice =>" + dice);
			
			if(dice == 4) {
				break;
			}
					
		}

			

	}
}
