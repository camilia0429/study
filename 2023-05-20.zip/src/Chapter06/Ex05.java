package Chapter06;

public class Ex05 {
	public static void main(String[] args) {
		int sum = 1;
		
		int n = 2;
		while (n <= 10) {
			sum = sum + n;
			
			n++;
		}
		System.out.println("1부터 10까지 합계 =>" + sum);
	}
}
