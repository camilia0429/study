package Chapter06;

public class Ex09 {
	public static void main(String[] args) {
		// 1 ~ 10 사이의 정수 중에서 짝수만 출력하는 프로그램
		
		int number = 1;
		
		while(number <= 10) {
			if(number % 2 ==1) {
				number++;
				continue;
			}
		
				
			System.out.println(number);
			
			number++;
		}
	}
}
