package Chapter06;

public class Ex06 {
	public static void main(String[] args) {
		
		int n;
		int m = 2;
		
			while (m <=9) {
				n = 1;
		
				while(n <= 9) {
					System.out.println(m + " X "  + n + "=" + (m*n));
					
					n++;
			}
			
			m++;
		}
	}
}
