package Chapter06;

import java.util.Scanner;

public class Ex13 {
	public static void main(String[] args) {
		// 사용자에게 영문 한 줄을 입력 받고
		// 입력 받은 영문 한 줄에서 대문자는 소문자로 변환하고
		// 소문자는 대문자로 변환해 출력하세요.
		
		Scanner scanf = new Scanner(System.in);
		
		String str = scanf.next();
		
		// 입력 받은 문자열 내 첫 번째 문자부터 마지막 문자까지 반복적으로 접근한다.
		// n번째 문자가 대문자라면 소문자로 바꾸고
		// n번째 문자가 소문자라면 대문자로 바꿔라.
		for(int n=0; n<str.length(); n++) {
			char nthCh = str.charAt(n);
			if(nthCh >= 'A' && nthCh <= 'Z') {
				nthCh = (char) ((int)nthCh + 32);
				System.out.println(nthCh);
			} else if(nthCh >= 'a' && nthCh <= 'z') {
				nthCh = (char) ((int)nthCh - 32);
				System.out.println(str);
			}
			
		}
		
		System.out.println(str);
	}
}
