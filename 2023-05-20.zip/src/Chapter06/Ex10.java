package Chapter06;

public class Ex10 {
	public static void main(String[] args) {
		// for문을 사용해서 "Hello World~!" 를 5번 출력하는 프로그램
		
		for(int count=1; count<=5; count++) {
			System.out.println("Hello World~!");
			
			continue;
		}
	}	
}
