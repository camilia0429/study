package Chapter06;

import java.util.Random;

public class Ex11 {
	public static void main(String[] args) {
		//for문을 사용해서 주사위를 3번 굴리는 프로그램
		Random random = new Random();
		
		for(int count=1; count<=5; count++) {
			int dice = random.nextInt(6) + 1;
			
			System.out.println("dice = " + dice);
		}
	}
}
