package Chapter06;

public class Ex04 {
	public static void main(String[] args) {
		int num = 2;
			while(num <= 18) {
			System.out.println(num);
			num = num + 2;
			}
	}
}
