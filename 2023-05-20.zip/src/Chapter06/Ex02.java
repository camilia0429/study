package Chapter06;

public class Ex02 {
	public static void main(String[] args) {
		
		int num = 10;
		
		while(num >= 1) {
				num--;
		}
		System.out.println("num = " + num);
	}
}
