package Chapter07;

public class Ex05 {
	public static void main(String[] args) {
		Phone p1 = new Phone();
		Phone p2 = new Phone();
		
		Phone.devicetype = "갤럭시 플립3";
		p1.price = 1100000;
		p1.company = "KT";
		
		Phone.devicetype = "갤럭시 S23 Ultra";
		p2.price = 1500000;
		p2.company = "알뜰폰 SKT";
		
		System.out.println(p1.devicetype);
		System.out.println(p2.devicetype);
	}
}
