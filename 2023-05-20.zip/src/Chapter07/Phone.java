package Chapter07;

public class Phone {
	static String devicetype;  	// 기종
	int price;					// 가격
	String company;				// 통신사
}
