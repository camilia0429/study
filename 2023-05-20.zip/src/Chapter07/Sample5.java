package Chapter07;

public class Sample5 {
	void func(int num) {
		num = num +1;
		
		System.out.println("num = " + num);
	}
	
	void func(int[] nums) {
		nums[0] = nums[0] + 1;
		
		System.out.println("nums[0] = " + nums[0]);
		
	}
}
