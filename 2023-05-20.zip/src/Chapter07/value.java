package Chapter07;

public class value {

}
