package Chapter07;

public class Ex07 {
	public static void main(String[] args) {
		// 배열 할 때 언급했음
		// 아래와 같이 arr 배열을 만들면 배열은 어떤 값을 가지고 있는 상태로 만들어진다고 했음
		int[] arr = new int[3];
		
		Student s = new Student();
		
		System.out.println(s.age);
		System.out.println(s.name);
	}
}
