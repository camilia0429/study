package Chapter07;

public class Ex17 {
	public static void main(String[] args) {
		// test 패키지에 있는 Sample1 클래스로 객체를 생성
		test.Sample1 ss = new test.Sample1();
		
		ss.a = 10;
		ss.b = 20;
	}
}
