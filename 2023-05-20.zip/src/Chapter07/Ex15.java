package Chapter07;

public class Ex15 {
	public static void main(String[] args) {
		Sample5 s= new Sample5();
		
		int[] numbers = {1, 2, 3};
		
		System.out.println("메서드 호출 전 numbers[0]의 값 => " + numbers[0]);
		
		s.func(numbers);
		
		System.out.println("메서드 호출 후 numbers[0]의 값 => " + numbers[0]);
		
		
//		int num = 5;
//		
//		System.out.println("메서드 호출 전 num 변수의 값 => " + num);
//		
//		s.func(num);
//		
//		System.out.println("메서드 호출 후 num 변수의 값 => " + num);
//		
	}
}
