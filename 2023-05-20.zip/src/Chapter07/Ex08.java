package Chapter07;

public class Ex08 {
	public static void main(String[] args) {
		Sample sample = new Sample();
		
		sample.outputADividingLine();
		
		System.out.println("<< 자기소개 >>");
		System.out.println("이름 => 홍길동");
		System.out.println("나이 => 23");
		System.out.println("주소 => 인천");
		
		
		sample.outputADividingLine();
		
		sample.onePlusone();
		sample.twotwo();
	}
}
