package Chapter07;

public class Ex14 {
	public static void main(String[] args) {
		Sample3 s = new Sample3();
		
		s.func1();
		Sample3.func2();
	}
}
