package Chapter07;

public class Ex13 {
	public static void main(String[] args) {
		Calculator c = new Calculator();
		
		String result = c.getEvenOrOdd(15);
		System.out.println(15 + "는" + result + "입니다.");
		
		double avg = c.getAvg(10, 9, 7);
		System.out.println("철수의 평균은" + avg + "점입니다.");
		
//		c.printAddTwoNumbers(1, 1);
//		
//		int result = c.returnAddTwoNumbers(1, 1);
//		System.out.println("1 + 1의 합은 " + result + "입니다.");
//		
//		result = c.returnAddTwoNumbers(result, 5);
		
	}
}
