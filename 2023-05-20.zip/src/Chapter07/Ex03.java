package Chapter07;

public class Ex03 {
	public static void main(String[] args) {
		Car myCar = new Car();
		Car fatherCar = new Car();
		
		System.out.println(myCar);
		System.out.println(fatherCar);
	}
}
