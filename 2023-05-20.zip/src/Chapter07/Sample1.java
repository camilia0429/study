package Chapter07;

public class Sample1 {
	// 매개변수가 없는 메서드
	void func1() {
		System.out.println("매개변수가 없는 func1 메서드");
	}
	
	
	// 매개변수가 있는 메서드 
	void func2(int a) {
		System.out.println("매개변수가 있는 func2 메서드");
		System.out.println("매개변수 a가 전달 받은 값 =" + a);
	}
	
	
	// 매개변수가 2개 있는 메서드
	void func3(int a, int b) {
		System.out.println("매개변수가 2개인 func3 메서드");
	}
	
	// 매개변수가 1개, 데이터타입이 double인 메서드
	void func4(double a) {
		System.out.println("매개변수가 1개이고 데이터 타입이 double인 func4 메서드");
	}
	
	// 매개변수가 3개인 메서드
	void func5(int number, int count, int person) {
		System.out.println("매개변수가 3개인 func5 메서드");
	}
}
