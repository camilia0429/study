package Chapter07;

public class Ex16 {
	// test 패키지에 있는 Person 클래스를 사용
	test.Person p = new test.Person();
}
