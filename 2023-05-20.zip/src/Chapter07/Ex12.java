package Chapter07;

public class Ex12 {
	public static void main(String[] args) {
		// Sample2 클래스 안에 선언한 func1, func2 두 메서드를 호출
		
		Sample2 s = new Sample2();
		
		s.func1();
		s.func2();
		
			
	}
}
