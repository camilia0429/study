package Chapter07;

public class Ex01 {
	public static void main(String[] args) {
		Computer myComputer;
		myComputer = new Computer();
		
		System.out.println(myComputer);
	}
}


