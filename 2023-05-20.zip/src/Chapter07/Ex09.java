package Chapter07;

public class Ex09 {
	public static void main(String[] args) {
		Sample1 s = new Sample1();
		
//	s.func1();
	s.func2(10);
	s.func2(32);
	s.func2(-4);
	
	
//	
//	//    괄호안에 들어가는 값을 '인자' 라고 함. (Argument)
//	//	  인자를 "복사"해서 인스턴트에 가져가고 매개변수에 저장함
//	s.func3(3, 2);
	//	  첫번째 인자는 첫번째 매개변수에, 두번째 인자는 두번째 매개변수에 저장이 됨
	}
}
