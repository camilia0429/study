package Chapter07;

public class Sample {
	/*
	 * 메서드 형식
	 * 
	 * 반환타입 메서드이름(매개변수) {
	 * 	소스코드1;
	 * 	소스코드2;
	 * 	...
	 * 	소스코드n;
	 * }
	 */
	
	void outputADividingLine() {
		System.out.println("----- ----- -----");
		System.out.println("----- ----- -----");
	}
		
	void onePlusone() {
		System.out.println("1 + 1 =" + (1 + 1));
		// 1 + 1 에는 괄호가 있어야함.
	}
	void twotwo() {
		for(int back=1; back<=9; back++) {
		System.out.println("2 X " + back + " = " + (2*back));
		}
	}
}
