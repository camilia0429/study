package Chapter07;

public class Ex02 {
	public static void main(String[] args) {
		Computer friendComputer = new Computer();
	}
}
