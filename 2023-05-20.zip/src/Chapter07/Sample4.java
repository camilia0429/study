package Chapter07;

public class Sample4 {
	void func() {
		System.out.println("매개변수가 없는 func 메서드");
	}
	
	void func(int a) {
		System.out.println("매개변수가 하나인 func 메서드");
	}
	
	void func(double a) {
		System.out.println("매개변수가 하나(double)인 func 메서드");
	}
	
	void func(int a, int b) {
		System.out.println("매개변수가 두개인 func 매서드");
	}
}
