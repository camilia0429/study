package Chapter07;

import java.util.Scanner;

public class Ex10 {
	
	public static void main(String[] args) {

		Scanner scanf = new Scanner(System.in);
		
		Calculator c = new Calculator();
		
		c.printPersonInformation("홍길동", 22, 173.5);
		
		c.printEvenOrOdd(1);
		
		
//		//반복문을 사용해서 구구단 2 ~ 9단까지 출력
//		for(int front=2; front<=9; front++) {
//			for(int back=1; back<=9; back++) {
//				System.out.println(front + " X " + back + " = " + (front*back));
//			}
//		}
//		

//		
//		for(int front=2; front<=9; front++) {
//			c.printGugudan(front);
//		}
//		
//		c.printGugudan(2);
//		c.printGugudan(6);
		
//		c.printAddTwoNumbers(1, 1);
//		c.printAddTwoNumbers(-7, 4);
		
	}
	
}
