package Chapter07;

public class Ex11 {
	public static void main(String[] args) {
		
		value v = new value();
	}
}
