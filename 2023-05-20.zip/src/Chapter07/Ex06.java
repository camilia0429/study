package Chapter07;

public class Ex06 {
	public static void main(String[] args) {
		Phone p1 = new Phone();
		Phone p2 = p1;
		
		p1.company = "KT";
		p2.company = "알뜰폰 LG";
		
		System.out.println(p1.company);
		System.out.println(p2.company);
	}
}
