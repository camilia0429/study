package Chapter07;

public class Car {
	// 세 자동차의 정보를 저장
	
	Car car1 = new Car();
	
	Car car2 = new Car();
	
	Car car3 = new Car();




	}
}
