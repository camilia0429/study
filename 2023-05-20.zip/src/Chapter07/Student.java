package Chapter07;

public class Student {
	String name;
	int age;
	String tel;
	String address;
}


