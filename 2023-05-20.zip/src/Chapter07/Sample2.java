package Chapter07;

public class Sample2 {
	//반환 타입이 없는 메서드
	void func1() {
		System.out.println("반환 타입이 없는 func1 메서드");
	}
	
	//반환 타입이 있는 메서드
	// 데이터타입 메서드이름 (매개변수)
	int func2() {
		System.out.println("반환 타입이 있는 func2 메서드");
		
		return 10;
	}
}
