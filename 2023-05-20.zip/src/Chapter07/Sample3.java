package Chapter07;

public class Sample3 {
	// (인스턴스) 메서드
	void func1() {
		System.out.println("static 키워드가 없으니까 메서드");
		System.out.println("인스턴스를 생성하는 시점에 만들어짐");
	}
	
	// 클래스 메서드
	static void func2() {
		System.out.println("static 키워드가 있으니까 클래스 메서드");
		System.out.println("선언하는 시점에 클래스의 정보 안에 만들어짐");
	}
}
