package Chapter07;

public class Ex04 {
	public static void main(String[] args) {
		//Student 클래스를 사용해서 인스턴트를 생성했다 = Student 클래스의 인스턴스를 생성했다.
		Student s1 = new Student();
		Student s2 = new Student();
		
		s1.name = "홍길동";
		s1.age = 23;
		s1.tel = "010-1111-1111";
		s1.address = "인천광역시 서구 ~~";
		// 멤버 변수 (필드)
		
		System.out.println("<< 첫번째 학생의 정보>>");
		System.out.println(s1.name);
		System.out.println(s1.age);
		System.out.println(s1.tel);
		System.out.println(s1.address);
		
		s2.name = "김영희";
		s2.age = 21;
		s2.tel = "010-2222-2222";
		s2.address = "인천광역시 부평구 ~~";
		
		System.out.println("<< 두번째 학생의 정보>>");
		System.out.println("이름 = " + s2.name);
		System.out.println("나이 = " + s2.age);
		System.out.println("연락처 = " + s2.tel);
		System.out.println("주소 = " + s2.address);
	}
}
