package Chapter07;

public class Calculator {
	void printAddTwoNumbers(int num1, int num2) {
		int result = num1 + num2;
		System.out.println(num1 + " + " + num2 + " = " + result);
	}
	
	int returnAddTwoNumbers(int num1, int num2) {
		int result = num1 + num2;
		return result;
	}
	
	void printGugudan(int gugudan) {
		for(int back=1; back<=9; back++) {
			System.out.println(gugudan + " X " + back + " = " + (gugudan*back ));
		}
	}
	
	void printEvenOrOdd(int number) {
		if(number % 2 == 1) {
			System.out.println("홀수");
		} else {
			System.out.println("짝수");
		}
	}
	
	void printPersonInformation(String name, int age, double height) {
		System.out.println("이름 =>" + name);
		System.out.println("나이 =>" + age);
		System.out.println("키 =>" + height);
		
		
//	int returnEvenOrOdd(int number) {
//		if(number % 2 == 1) {
//			System.out.println("홀수");
//		} else {
//			System.out.println("짝수");
//		}
//		
	}
	
		String getEvenOrOdd(int su) {
			String result;
			
			if(su % 2 == 1) {
				result = "홀수";
			} else {
				result = "짝수";
			}
			return result;
		}

		double getAvg(int kor, int eng, int mat) {
			int total = kor + eng + mat;
			double avg = (double) total / 3;
			
			return avg;
			
		}	
	}
		
//	String returnEvenOrOdd(int su) {
//		String result;
//		
//		if(su & 2 == 1) {
//			return "홀수";
//		} else {
//			return "짝수";
//		}
//	}
		
//	int returnKorEngMath(int Kor, int Eng, int Math) {
//		System.out.println("국어 점수 =>" + Kor);
//		System.out.println("영어 점수 =>" + Eng);
//		System.out.println("수학 점수 =>" + Math);
//		System.out.println("국,영,수 평균 =>" + (Kor + Eng + Math / 3));
//		
//		
