package Chapter09;

public class Rabbit extends Animal {

}
