package Chapter09;

public class Vegetable extends Product {

}
