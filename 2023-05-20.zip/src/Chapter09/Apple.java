package Chapter09;

public class Apple extends Fruit {

}
