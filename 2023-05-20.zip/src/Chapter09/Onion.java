package Chapter09;

public class Onion extends Vegetable {

}
