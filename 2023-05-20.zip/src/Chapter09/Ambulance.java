package Chapter09;

public class Ambulance extends Car {
	public void siren() {
		System.out.println("!! siren !!");
	}
}
