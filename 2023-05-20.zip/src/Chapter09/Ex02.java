package Chapter09;

public class Ex02 {
	public static void main(String[] args) {
		Car car = null;
		FireEngine fe1 = new FireEngine();
		FireEngine fe2 = null;
		
		// 형변환 (fe1 변수에 저장된 값을 Car 타입에 저장하겠다)
		// car. 할 경우 car가 Car객체이므로 FireEngine의 데이터 값은 나타나지 않음
		// 반면 fe1. fe2.를 할 경우 FireEngine객체이므로 모든 데이터 값이 나타남
		car = (Car) fe1;
		fe2 = (FireEngine) car;
		
		System.out.println(car);
		System.out.println(fe1);
		System.out.println(fe2);
		
	}
}
