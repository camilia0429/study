package Chapter09;

public class PortableFan {

}
