package Chapter09;

public class Fruit extends Product {

}
