package Chapter09;

public class ZooKeeper {
	private String name;
	
	public void feed(Animal animal) {
		System.out.println(animal.getname() + "에게 먹이를 준다.");
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
		
	}
}
