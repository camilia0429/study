package Chapter09;

public class Animal {
	private String name;
	
	public String getname() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
}
