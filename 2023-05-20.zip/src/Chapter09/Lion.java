package Chapter09;

public class Lion extends Animal {

}
