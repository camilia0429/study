package Chapter09;

public class Ex01 {
	public static void main(String[] args) {
		ElectricFan fan1 = new ElectricFan();
		WallMountedFan fan2 = new WallMountedFan();
		
		//다형성이 적용된 개체
		ElectricFan fan3 = new WallMountedFan();
		
		WallMountedFan fan4 = new ElectricFan();
		fan4.hangfan();
	}
}
