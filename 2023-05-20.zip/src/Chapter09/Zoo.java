package Chapter09;

public class Zoo {
	public static void main(String[] args) {
		Animal lion1 = new Lion();
		lion1.setName("Simba");
		
		Animal lion2 = new Lion();
		lion2.setName("Mufasa");
		
		Animal rabbit = new Rabbit();
		rabbit.setName("Bunny");
		
		ZooKeeper zk = new ZooKeeper();
		zk.setName("홍길동");
		
		// Simba에게 먹이를 준다
		zk.feed(lion1);
		
		// Mufasa에게 먹이를 준다
		zk.feed(lion2);
		
		// Bunny에게 먹이를 준다
		zk.feed(rabbit);
		
		
	}
}
