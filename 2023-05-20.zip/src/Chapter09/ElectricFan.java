package Chapter09;

public class ElectricFan {
	private boolean power;
	private int fanStrenth;
	private boolean rotation;
	
	public boolean isPower() {
		return power;
	}

	public void setPower(boolean power) {
		this.power = power;
	}

	public int getFanStrenth() {
		return fanStrenth;
	}

	public void setFanStrenth(int fanStrenth) {
		this.fanStrenth = fanStrenth;
	}

	public boolean isRotation() {
		return rotation;
	}

	public void setRotation(boolean rotation) {
		this.rotation = rotation;
	}

	public void powerOnOff() {
		System.out.println("powerOnOFF 메서드 호출");
	}
	
	public void pushFanStrength() {
		System.out.println("pushFanStrength 메서드 호출");
	}
	
	public void rotationSwitch() {
		System.out.println("rotationSwitch 메서드 호출");
	}
}
