package Chapter09;

public class WallMountedFan extends ElectricFan {
	private String location;
	
	public void hangfan() {
		System.out.println("hangFan 메서드 호출");
	}
}
