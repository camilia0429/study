package Chapter09;

public class FireEngine extends Car {
	public void water() {
		System.out.println("water~~~~~~~~~");
	}

}
