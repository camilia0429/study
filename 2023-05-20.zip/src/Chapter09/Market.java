package Chapter09;

public class Market {
	public static void main(String[] args) {
		
		Fruit[] fruitShelf = new Fruit[2];
		fruitShelf[0] = new Apple();
		fruitShelf[1] = new Banana();
		
		Vegetable[] vegetableShelf = new Vegetable[1];
		vegetableShelf[0] = new Onion();
		
		// 사과 3개를 담을 수 있는 바구니
		// 사과들을 담을 수 있는 배열
		Product[] basket = new Product[3];
		basket[0] = fruitShelf[0];
		basket[1] = fruitShelf[1];
		basket[2] = vegetableShelf[0];
		

	}
}
