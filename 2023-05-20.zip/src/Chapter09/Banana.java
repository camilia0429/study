package Chapter09;

public class Banana extends Fruit {

}
