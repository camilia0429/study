package Chapter09;

public class Ex03 {
	public static void main(String[] args) {
		Car car = new Car();
		FireEngine fe1 = null;
		FireEngine fe2 = null;
		
		// 이 코드는 문제가 있는 코드임.
		// FireEngine 인스턴스에 들어있지 않은 것을 car(Car인스턴스) 객체 내에서
		// 찾을 수 없어 오류가 발생함.
		// 다운캐스팅임
		fe1 = (FireEngine) car;
		fe2 = fe1;
	}
}
