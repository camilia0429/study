package chapter03;

public class Ex06 {
	public static void main(String[] args) {
		char ch1 = 'A';
		char ch2 = 'a';
		
		System.out.println(ch1 == ch2);
		
		System.out.println(ch1 < ch2);
		
		//아스키코드표 참고 A = 65 , a = 97
		
		System.out.println(ch1 > ch2);
		
//		int num1 = 23;
//		int num2 = 22;
//		
//	
//
//		boolean result = num1 < num2;
//		
	}
}
