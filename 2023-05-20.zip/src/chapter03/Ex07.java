package chapter03;

public class Ex07 {
	public static void main(String[] args) {
		// 문자열은 == (같다), !=(다르다) 외에는 비교연산을 할 수 없음.
		String str1 = "A";
		String str2 = "A";
		
		// 변수는 heap 영역에, 문자열 값은 문자열을 위한 공간에 
		// String = 참조 변수
		// "A" 값이 저장된 데이터 공간을 참조하므로, str1과 str2의 주소는 같음
		
		// 아래 비교 연산이 어떤걸 비교하는지 지난 시간에 배운
		// 문자열과 관련된 내용을 떠올리면서 잘 판단해보세요.
		System.out.println(str1 == str2);
	}
}
