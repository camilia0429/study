package chapter03;

public class Ex05 {
	public static void main(String[] args) {
		System.out.println(10 / 3);
		// 몫에 소수점이 붙기 직전까지 최대한 나누고
		// 몫에 소수점이 붙는 순간 나누기 스탑(Stop)!
		// 멈췄을 때의 나머지를 구해줌
		System.out.println(10 % 3);
		
		System.out.println(9 % 3);
		System.out.println(8 % 3);
		System.out.println(7 % 3);
		// % 연산의 결과는 0 ~ 분모 -1 사이의 수 중에 하나
	}
}
