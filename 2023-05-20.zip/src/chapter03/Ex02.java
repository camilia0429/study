package chapter03;

public class Ex02 {
	public static void main(String[] args) {
		System.out.println(3 + 10);
		System.out.println(3 - 10);
		System.out.println(3 * 10);
		System.out.println(3 / 10);
		// 정수/정수 는 '실수'일 수도 있음. = 0.3에서 정수인 '0'만 출력하므로 값은 '0'
		
		System.out.println(3.1 + 10.9);
		// 실수와 실수를 '연산' 했으므로 결과값은 '실수'
		// ex ) 3.1 + 10.9 였을 경우 > 14.0(실수)으로 출력됨.
		
		System.out.println(3.1 + 10);
		System.out.println(3 + 10.9);
		
		System.out.println(3.0 / 10.0);
	}
}
