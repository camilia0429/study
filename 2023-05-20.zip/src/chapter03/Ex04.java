package chapter03;

public class Ex04 {
	public static void main(String[] args) {
		int a = 10;
		double b = a;
		// a는 int(정수)이므로 (double) a를 통해 실수로 바뀐게 아님. 단지 복사 후 실수로 변환
		// '업캐스팅' = 정수가 실수로 변환
		int c = (int) 1.5;
		// 여기에서 1.5를 정수로 바꾸었으므로 c=1
		// '다운캐스팅' = 실수를 정수로 변환
		
		char d = (char) 67;
		
		System.out.println(d);
		//67 을 문자열로 전환 하면 '아스키코드표를 참조' d = C
		c = 'Y';
		//Y 를 정수로 전환 하면 '아스키코드표를 참조' c = 89
		// '업캐스팅' = 문자가 정수로 변환
		System.out.println(c);
		
	}
}
