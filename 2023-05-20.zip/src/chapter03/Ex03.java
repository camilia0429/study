package chapter03;

public class Ex03 {
	public static void main(String[] args) {
		int var1 = 31;
		int var2 = 56;
		int var3 = 41;
		
		int theNumberOfSubjectsITook = 3;
		
		int total = var1 + var2 + var3;
		double avg = (double) total / theNumberOfSubjectsITook;
		// 형변환이 먼저 됨 total = 128.0 / 3 : 결과값은 실수
			System.out.println(total);
			System.out.println(avg);
		
		
	}
}
