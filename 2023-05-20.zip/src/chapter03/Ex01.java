package chapter03;

public class Ex01 {
	public static void main(String[] args) {

		System.out.println(10 + 20);

		int result = 10 + 20;

		int var1 = 10;
		// var1변수에 들어있는 값을 "복사"한 후 20과 곱한 결과를 result 변수에 저장
		result = var1 * 20;
		
		int var2 = 20;
		// var1변수에 들어있는 값을 "복사"한 후 var2변수에 들어있는 값을 복사
		// 복사가 된 두 값을 나눈 결과를 result 변수에 저장 
		result = var1 / var2;
		
		
	}
}
