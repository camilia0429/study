package Chapter12;

import java.util.HashSet;
import java.util.Iterator;

public class Ex08 {
	public static void main(String[] args) {
		HashSet<Integer> set = new HashSet<Integer>();
		
		set.add(1);
		set.add(2);
		set.add(3);
		
		Iterator<Integer> it = set.iterator();
		
		while(it.hasNext()) {
			int number = number = it.next();
			System.out.println(number);
			
		}
	}
}
