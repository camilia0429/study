package Chapter12;

public class Ex02 {
	public static void main(String[] args) {
		
		
		Customer c1 = new Customer("홍길동", "010-1111-1111", 5);
		Customer c2 = new Customer("홍길동", "010-1111-1111", 5);
		
		if(c1.equals(c2)) {
			System.out.println("두 객체가 같은 정보를 가지고 있습니다.");
		} else {
			System.out.println("두 객체가 다른 정보를 가지고 있습니다.");
		}
	}
}
