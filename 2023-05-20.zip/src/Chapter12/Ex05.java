package Chapter12;

import java.util.HashSet;

public class Ex05 {
	public static void main(String[] args) {
		HashSet<Integer> set = new HashSet<Integer>();
			
		for(int number=1; number<=10; number++) {
			set.add(number);
		}
		
		System.out.println(set);
		
		for(int number : set) {
			if(number % 2 == 0) {
				System.out.println(number);
			}
		}
	}
}
