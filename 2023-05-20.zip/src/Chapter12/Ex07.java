package Chapter12;

import java.util.HashSet;
import java.util.Scanner;

public class Ex07 {
	public static void main(String[] args) {
		
		Scanner scanf = new Scanner(System.in);
		HashSet<String> lyrics = new HashSet<String>();
		
		while(true) {
		System.out.print("노래 가사를 입력하세요.(종료 : -1 :");
		String str = scanf.next();
		
		if(str.equals("-1")) {
			break;
		}
		
		boolean result = lyrics.add(str);
		if(!result) {
			System.out.println("이미 저장된 노래가사입니다.");
			System.out.println("노래 가사 : " + str);
		}
	
		}
		
		System.out.println(lyrics);
		
		//노래 가사에 set 저장 > 이미 임력한 가사는 안내문구와 함께 출력
		
		
	}
}