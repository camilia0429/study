package Chapter12;

public class Person {
	private String tel;
	private String paymeonMethod;
	public Person(String string, String string2) {
		// TODO Auto-generated constructor stub
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getPaymeonMethod() {
		return paymeonMethod;
	}
	public void setPaymeonMethod(String paymeonMethod) {
		this.paymeonMethod = paymeonMethod;
	}

	
}
