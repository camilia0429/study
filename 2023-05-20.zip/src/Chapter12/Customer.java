package Chapter12;

import java.util.Objects;

public class Customer {
	private String name;
	private String tel;
	private int seat;
	
	@Override
	public String toString() {
		return "Customer [name=" + name + ", tel=" + tel + ", seat=" + seat + "]";
	}
	
	public Customer(String name, String tel, int seat) {
		this.name = name;
		this.tel = tel;
		this.seat =  seat;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(name, seat, tel);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		return Objects.equals(name, other.name) && seat == other.seat && Objects.equals(tel, other.tel);
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public int getSeat() {
		return seat;
	}
	public void setSeat(int seat) {
		this.seat = seat;
	}

}
