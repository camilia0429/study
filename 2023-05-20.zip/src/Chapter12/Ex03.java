package Chapter12;

import java.util.ArrayList;

public class Ex03 {
	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		
		if(list.isEmpty()) {
			System.out.println("리스트가 비어있습니다.");
		} else {
			System.out.println("리스트에 데이터가 들어있습니다.");
		}
		
		list.add(1);
		list.add(2);
		list.add(3);
		
		if(list.isEmpty()) {
			System.out.println("리스트가 비어있습니다.");
		} else {
			System.out.println("리스트에 데이터가 들어있습니다.");
		}
		
		list.set(1, 4);
		
		System.out.println(list);
		
		list.remove(Integer.valueOf(4));
		
		list.
		
		System.out.println(list.contains(4));
		if(list.contains(4)) {
			System.out.println("리스트 안에 2가 들어있습니다");
		} else {
			System.out.println("리스트 안에 2가 없습니다");
		}
		
		list.clear();
		System.out.println(list);
	}
}
