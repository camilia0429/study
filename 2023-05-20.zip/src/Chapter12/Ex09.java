package Chapter12;

import java.util.HashSet;
import java.util.Set;

public class Ex09 {
	public static void main(String[] args) {
		
		Set<Book> bookSet = new HashSet<>();
		
		bookSet.add(new Book("Java Master", 34500));
		bookSet.add(new Book("JSP/Servlet 입문", 29000));
		
		System.out.println(bookSet);
		
		bookSet.add(new Book("JSP/Servlet 입문", 29000));
		
		System.out.println(bookSet);
	
	}
}
