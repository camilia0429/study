package Chapter12;

import java.util.ArrayList;

public class Ex01 {
	public static void main(String[] args) {
		ArrayList<Customer> customerList = new ArrayList<Customer>();
		
		Customer c1 = new Customer("홍길동" , "010-1473-3698", 32);
		Customer c2 = new Customer("고영희" , "010-1598-7894", 55);
		
		customerList.add(c1);
		customerList.add(c2);
		
		// customerList를 사용해서 승차권을 구매한 모든 구매자의 정보를 출력하세요.
		for(int i=0; i<customerList.size(); i++) {
			Customer nthCustomer = customerList.get(i);
			
			System.out.println(nthCustomer);
			
		}
		
		// 문제 풀이
		
		Customer c0 = new Customer("김영수" , "010-7536-9514", 17);
		customerList.add(0, c0);
		
		for(int i=0; i<customerList.size(); i++) {
			Customer nthCustomer = customerList.get(i);
			
			System.out.println(nthCustomer);
		}
		// KTX 승차권을 환불함.
		
	/*	customerList.remove(1);
		
		for(int i=0; i<customerList.size(); i++) {
			Customer nthCustomer = customerList.get(i);
			
			System.out.println(nthCustomer);
			
	*/	
		Customer refundedCustomer = new Customer("홍길동", "010-1473-3698", 32);
		
		for(int i=0; i<customerList.size(); i++) {
			Customer nthCustomer = customerList.get(i);
			
		String nthCustomerName = nthCustomer.getName();
		String nthCustomerTel = nthCustomer.getTel();
		int nthCustomerSeat = nthCustomer.getSeat();
		
		String refundedCustomerName = refundedCustomer.getName();
		String refundedCustomerTel = refundedCustomer.getTel();
		int refundedCustomerSeat = refundedCustomer.getSeat();
		
		if (nthCustomerName.equals(refundedCustomerName) && nthCustomerTel.equals(refundedCustomerTel) && nthCustomerSeat == refundedCustomerSeat) {
		
			customerList.remove(i);
			break;
			}
		}
		
		for(int i=0; i<customerList.size(); i++) {
			Customer nthCustomer = customerList.get(i);
			
			System.out.println(nthCustomer);
		
			
		}
	}
}

