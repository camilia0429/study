package Chapter12;

import java.util.HashSet;

public class Ex06 {
	public static void main(String[] args) {
		HashSet<Character> set = new HashSet<Character>();
		
		for(char ch='a'; ch <= 'z'; ch++) {
			set.add(ch);
		}
		
		System.out.println(set);
		
		int n = 1;
		
		for(char ch : set) {
			if(n % 2 == 0) {
				System.out.println(ch);
				
			}
			
			n++;
			
		}	
	}
}

