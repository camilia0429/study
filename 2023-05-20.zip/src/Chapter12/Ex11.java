package Chapter12;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Ex11 {
	public static void main(String[] args) {
		Map<String, Person> personMap = new HashMap<>();

		Person p1 = new Person("010-4473-3698", "현금");
		
		Person p2 = new Person("010-1598-7894", "카드");
		
		Person p3 = new Person("010-4569-1236", "카드");
		
		personMap.put("홍길동", p1);
		personMap.put("김철수", p2);
		personMap.put("고영희", p3);
		
		Set<String> keys = personMap.keySet();
		for(String key : keys) {
			Person nthPerson = personMap.get(key);
			
			String nthPersonPaymentMethod = nthPerson.getPaymeonMethod();
			
			if(nthPersonPaymentMethod.equals("현금")) {	
				System.out.println("이름 : " + key);
				System.out.println("연락처 : " + nthPerson.getTel());
				System.out.println("결제방법 : " + nthPerson.getPaymeonMethod());
			
			}
		}
	}
}
