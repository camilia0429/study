package Chapter12;

import java.util.HashSet;

public class Ex04 {
	public static void main(String[] args) {
		HashSet<Integer> set = new HashSet<Integer>();
		
		set.add(1);
		set.add(3);
		set.add(5);
		set.add(7);
		
		System.out.println(set);
		
		set.add(1);
		
		System.out.println(set);
		
		set.remove(set);
		
		System.out.println(set);
		
		for(int number : set) {
			System.out.println(number);
		}
	}
}
