package Chapter12;

import java.util.HashMap;
import java.util.Map;

public class Ex10 {
	public static void main(String[] args) {
		Map<String, Integer> korMap = new HashMap<>();
		
		korMap.put("홍길동", 95);
		korMap.put("김철수", 86);
		korMap.put("고영희", 35);
		
		System.out.println(korMap);
		
		//먼저 저장되어있던 데이터가 삭제됨 
		korMap.put("홍길동", 71);
		
		System.out.println(korMap);
		
		int result = korMap.get("홍길동");
		System.out.println("홍길동의 국어점수 : " + result);
		
		korMap.remove("홍길동");
		
		System.out.println(korMap);
	}
}
