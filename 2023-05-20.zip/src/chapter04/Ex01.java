package chapter04;

public class Ex01 {
	public static void main(String[] args) {
		// 논리값(boolean) : true, false
		// > 결과값이 두개인 경우에 주로사용. O,X 있음,없음 등.
		boolean turnOn = true;
		boolean powerOn = true;
		
		
		System.out.println(turnOn && powerOn);
		
		int kor = 670;
		
		System.out.println((kor >= 0) && (kor <= 100));
		// true - 만족 / false - 불만족 이라고도 표현함.
		// 비교 연산자와 논리 연산자를 사용해서 범위를 제한할 수 있음
		// 여러가지 연산자가 들어갈 경우 괄호를 활용하여 가독성 높게 코드를 짜도록 하자.
				
		
		System.out.println((kor < 0) || (kor > 100));
		// kor 변수에 들어있는 값이 0보다 작나요? 또는 kor 변수에 들어있는 값이 100보다 큰가요?
		
		System.out.println(true || false);
		System.out.println(false || true);
	}
}
