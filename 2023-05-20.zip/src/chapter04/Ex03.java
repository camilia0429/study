package chapter04;

public class Ex03 {
	public static void main(String[] args) {
		
		int chulsooKorScore = 60;
		int cutline = 65;
		char grade = chulsooKorScore > cutline ? 'P' : 'F';
		//           논리값이T 면 grade 변수는 P가 됨
		//           논리값이F 면 grade 변수는 F가 됨
		// ex) 철수가 커트라인을 넘겼으면 P, 못넘겼으면 F로 저장하고자 할 때.
		// 요즘은 주석보다 가독성을 높이기 위해 변수를 활용하는 것이 좋다.
		
		System.out.println("철수의 상황 => " + grade);
		
	}
}
