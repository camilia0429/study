package chapter04;

public class Ex02 {
	public static void main(String[] args) {
		// 증감 연산자 : 덧셈,뺄셈을 간추려서 할 수 있게 해주는 연산자
		
		int num = 1;
		
		// num 변수에 들어있는 값을 하나 증가시키고
		// num 변수의 값을 출력하세요
		// 단, num = 2 코드는 안됨
		// 변수명과 덤셈 연산자만 사용해서 하나 증가시키세요
		
		// num = num +1;
		++num;
		// = num++;
		System.out.println(num);
	}
}
