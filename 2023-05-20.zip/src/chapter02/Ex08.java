package chapter02;

public class Ex08 {
	public static void main(String[] args) {
		// 변수 : 임의 값(정수, 실수, 문자, 문자열, 논리)을 저장할 수 있는 공간
		// 상수 : 처음 저장한 값만 저장할 수 있는 공간
		final int num;
		num = 10;
	
		final int num2 = 10;
		 
		System.out.println(num);
		
		
	}
}
