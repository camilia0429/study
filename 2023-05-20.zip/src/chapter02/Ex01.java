package chapter02;

public class Ex01 {
	public static void main(String[] args) {
		// 자료형 변수명;		
		char value;
		value = 'a';
		int number;
		number = 2;
		double data;
		data = 3.14;
		boolean val1;
		val1 = true;
		
		

	}
}
