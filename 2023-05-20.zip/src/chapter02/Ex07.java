package chapter02;

public class Ex07 {
	public static void main(String[] args) {
		// 데이터 타입이 기본 데이터 타입인 변수
		int val1 = 10;
		
		// 데이터 타입이 참조 데이터 타입인 변수
		String val2 = "홍길동";
			
	}
}
