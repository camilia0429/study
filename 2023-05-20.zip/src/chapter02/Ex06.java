package chapter02;

public class Ex06 {
	public static void main(String[] args) {
		byte val1 = 10;
		short val2 = 32767;
		int val3 = 100000000;
		long val4;
// 1 / 2 / 4 / 8 byte 사용 = 15byte 사용
		
		
		
		
		
		
		
		double val5 = 3.14;
		float val6 = 3.14f;
		
		char val7;
		
		boolean val8;
	}
}
