package chapter02;

public class Ex03 {
	public static void main(String[] args) {
		String name = "김철수";
		System.out.println("이름 : " + name);
		int age = 23;
		System.out.println("나이 : " + age);
		String home = "인천광역시";
		System.out.println("주소 : " + home);
		double tall = 170.5;
		System.out.println("키 : " +tall);
	}
}
