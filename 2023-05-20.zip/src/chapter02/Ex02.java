package chapter02;

public class Ex02 {
	public static void main(String[] args) {
		// 선언하면서 값을 저장 : 자료형 변수명 = 저장할 값;
		
			 int value = 1;
			 System.out.println(value);
			 value = 2;
			 System.out.println(value);
			 boolean sunny = false;
			 String happy = "ABC";
			 
	}
}
