package chapter02;

public class Ex05 {
	public static void main(String[] args) {
		// 변수명을 짓는 규칙 : 영문자, 숫자, 특수문자($, _)만 사용할 수 있다.
		String my_address;
		my_address = "나의 주소:" + "인천광역시";
		int last_lunch;
		last_lunch = 100 + 100;
		int last_month_withdrawal;
		last_month_withdrawal = 1000000;
		
		
		
	}
}
