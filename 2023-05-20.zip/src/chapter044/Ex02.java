package chapter044;

public class Ex02 {
	public static void main(String[] args) {
		//철수, 영희, 길동이의 국어점수의 합계와 평균을 계산해 출력하세요.
		//철수의 국어점수 : 31
		//영희의 국어점수 : 86점
		//길동의 국어점수 : 81점
		
		
		//배열을 사용해서 학생들의 국어점수를 저장
		
		//배열에 저장된 학생들의 국어점수를 사용해서 합계를 계산해 적절한 공간에 저장
		
		//위에서 계산한 합계로 평균을 계산
		
		//합계와 평균을 출력
		
		int[] kor = new int[3];
		
		kor[0] = 31;
		kor[1] = 86;
		kor[2] = 81;
		
		int result = kor[0] + kor[1] + kor[2];
		
		System.out.println("국어점수 합계" + result);
		
		double avg = result / (double)3;
		
		System.out.println("국어점수 평균" + avg);
		
		System.out.println("철수의 점수" + kor[0]);
		System.out.println("영희의 점수" + kor[1]);
		System.out.println("길동이의 점수" + kor[2]);
		
	}
}
