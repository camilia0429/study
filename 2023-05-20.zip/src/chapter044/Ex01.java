package chapter044;

public class Ex01 {
	public static void main(String[] args) {
		int val;
		// val변수에 정수를 저장할게
		
		int[] arr;
		// 정수들이 저장된 공간의 이름을 arr로 할게
		arr = new int[3];
		// 이름이 arr인 공간에 정수를 최대 3개까지 저장할게
		
		arr[0] = 5;
		// arr의 0번 인덱스에 5를 저장
		
		
		// 위 코드를 하나로 합치면 아래와 같다
		// 정수들이 저장된 공간의 이름을 arr로 하고 그 공간에 정수를 최대 3개까지 저장할게
		int[] arr2 = new int[3];
		
		// 이름이 arr3인 공간에 실수를 최대 5개 저장할게
		
		double[] arr3 = new double[5];
		
		//arr3 배열의 2번째 공간에 75.1을 저장
		arr3[1] = 75.1;
		
		// 아래 코드를 우리말로 해석해보세요.
		
		char[] arr4 = new char[1];
		// 이름이 arr4인 공간에 문자를 최대 1개 저장할게
	}
}
