package chapter044;

public class Ex03 {
	public static void main(String[] args) {
		
		// 뭐가 들어있는지 모르는 상태
		int val;
		
		
		// 참조하고 있는 공간이 없는 상태 = null
//		int[] arr1;
		
//		arr1[0] = 10;
		
		//데이터 타입 값에 맞는 기본값을 저장함. 아래에 같은 경우 정수이므로 0이 0,1,2번 인덱스에 저장됨.
		int[] arr1 = new int[3];
		
		int[] arr2 = arr1;
		
		arr1[0] = 10;
		
		
		
	}
}
