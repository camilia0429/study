package chapter044;

public class Ex04 {
	public static void main(String[] args) {
//		String str1 = "Hello";
//		String str2 = "Hello";
		
		String str1 = new String("Hello");
		String str2 = new String("Hello");
		
		System.out.println(str1 == str2);
		
		// str1이 가지고 있는 문자열과 str2가 가지고 있는 문자열이 같나요? 가 절대 아님!
		// str1이 참조하고 있는 문자열의 주소와 str2가 참조하고 있는 문자열의 주소가 같나요? 임!!
		
		
		// str1이 가지고 있는 문자열과 str2가 가지고 있는 문자열이 같나요? 인 코드를 쓰고싶으면
		// 아래와 같이 쓰면 됨
		
		System.out.println(str1.equals(str2));
	}
}
