package chapter01;

public class Ex03 {
	public static void main(String[] args) {
		System.out.println("Hello");
		//ln = "엔터를 쳐"
		System.out.println("World~!");


	}
}
