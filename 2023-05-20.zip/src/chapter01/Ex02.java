// 패키지 정의
package chapter01; // 패키지 정의
// 패키지 정의

// 클래스 정의
public class Ex02 {
	public static void main(String[] args) {		
		/*
		 * main(시작점)이 반드시 있어야함
		 * 왜? 컴퓨터는 멍청해서 시작점이 없으면
		 * 어디서부터 명령을 수행해야할 지 모름
		 * 
		 * 소스코드의 끝은 반드시 ;(세미콜론)으로 끝나야함
		 */
		System.out.println("Hello World~!");
	}
}
