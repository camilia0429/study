package chapter01;

public class Ex04 {
public static void main(String[] args) {
	System.out.println(23);
	//내가 '23살' 이라고 표현하고 싶다면, '살'이라는 단어가 붙은 순간 문자열이 되어 ""활용해야함
	System.out.println('A');
	System.out.println("김철수");
	System.out.println("2023-05-20");
	//" 없이 2023-05-20으로 할 경우 > 2023-05-20 = 1998 이 나올 수 있음
	
	System.out.println("Hello World~!");
	System.out.println("Hello\n\n\n\n\nWorld~!");
	System.out.println("철수의 나이는"+23+"살입니다.");	
	// "안에 있는 23 이라는 숫자는 문자열이므로 개별적으로 읽어야 함
}
}
