package test;

public class Ex02 {
	public static void main(String[] args) {
		// 사용자에게 두 수와 연산자를 입력 받아서
		// 연산자에 맞는 계산 결과를 구하고 출력하는 프로그램
		
		Calculator c = new Calculator();
		
		int su1 = c.su1Input();
		int su2 = c.su2input();
		char op = c.opInput();
		
		c.printResult(op, su1, su2);
	}
}
