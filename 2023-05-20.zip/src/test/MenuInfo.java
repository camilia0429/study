package test;

public class MenuInfo {
	private String name;
	private int price;
	private String recipe;
	private String category;
	
	//name 멤버 변수에 데이터를 저장하는 메서드
	public void setName(String name) {
		this.name = name;
		
	}
	
	public void setPrice(int price) {
		this.price = price;

	}
	
	public void setRecipe(String recipe) {
		this.recipe = recipe;
	}
	
	public void setCategory(String category) {
		this.category = category;
		
	//name 멤버 변수의 값을 반환하는 메서드
	}
	
	public void getName(String name) {
		this.name = name;
	}
}
