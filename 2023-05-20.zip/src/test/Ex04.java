package test;

public class Ex04 {
	public static void main(String[] args) {
	Sample1 s = new Sample1();
	
	s.a = 10;
	s.b = 20;
	
	}	
}
