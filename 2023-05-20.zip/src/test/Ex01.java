package test;

import Chapter07.Computer;

public class Ex01 {
	public static void main(String[] args) {
		Computer c = new Computer();
		
	}
}
