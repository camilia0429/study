package test;

public class Car {
	private String brand;   //자동차의 브랜드
	private int color;		// 자동차의 색상
	private String type;	// 자동차의 유형
	
	public Car(String brand) {
		this.brand = brand;
	}
	
		public Car(String brand, int color) {
			this(brand, color, "");
			
			this.brand = brand;
			this.color = color;
		}
	
	//Car 클래스의 생성자
	// 생성자 메서드는 호출하는게 아니다
	// 생성자 메서드는 인스턴스를 생성할 때 마다 자동으로 호출이 됨
	public Car(String brand, int color, String type) {
		System.out.println("Car 클래스의 생성자 호출");
	}
	
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public int getColor() {
		return color;
	}
	public void setColor(int color) {
		this.color = color;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
}
