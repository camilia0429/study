package test;

public class Sample1 {
	public int a;
	int b;
	private int c;
	
	public void func1() {
		System.out.println("접근 제어자가 public인 메서드");
	}
	
	void func2() {
		System.out.println("접근 제어자가 default인 메서드");
	}
	
	private void func3() {
		System.out.println("접근 제어자가 private인 메서드");
	}
}
