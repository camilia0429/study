package test;

class Person {
	String name;
	int age;
	double height;
	String address;
	
	// 정보를 저장할 객체와 그 객체에 저장할 정보를 전달 받아서
	// 객체에 정보를 저장하는 메서드
	void savePersonInformation(String name, int age, double height, String address) {
		this.name = name;
		this.age= age;
		this.height = height;
		this.address = address;
		
	}
	
	//this 키워드를 사용해서 이 인스턴스 안에 멤버 변수를 출력
	// 사람의 정보를 출력
	
	void printPersonInformation() {
		System.out.println("이름 =>" + this.name);
		System.out.println("나이 =>" + this.age);
		System.out.println("키 =>" + this.height);
		System.out.println("주소 =>" + this.address );
	}
}
