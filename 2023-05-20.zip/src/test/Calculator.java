package test;

import java.util.Scanner;

public class Calculator {
	int su1Input() {
		Scanner scanf = new Scanner(System.in);
		
		System.out.print("첫 번째 수 >>");
		int su1 = scanf.nextInt();
		
		return su1;
	}
		

		
	int su2input() {
		Scanner scanf = new Scanner(System.in);
		
		System.out.print("두 번째 수 >>");
		int su2 = scanf.nextInt();
		
		return su2;
	}
		
	char opInput() {
		Scanner scanf = new Scanner(System.in);
		 
		System.out.println("연산자 >>");
		char op = scanf.next().charAt(0);
		
		return op;
		
	}
	
	void printResult(char op, int su1, int su2) {
		if(op == '+') {
			System.out.println(su1 + " + " + su2 + " = " + (su1 + su2));
		} else if(op == '-') {
			System.out.println(su1 + " - " + su2 + " = " + (su1 - su2));
		} else if(op == '*') {
			System.out.println(su1 + " * " + su2 + " = " + (su1 * su2));
		} else if(op == '/') {
			System.out.println(su1 + " / " + su2 + " = " + ((double) su1 / su2));
		}
	}
}
