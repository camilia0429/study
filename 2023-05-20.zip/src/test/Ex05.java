package test;

public class Ex05 {
	public static void main(String[] args) {
		MenuInfo m1 = new MenuInfo();
		MenuInfo m2 = new MenuInfo();
		MenuInfo m3 = new MenuInfo();
		
		// 자바는 멤버 변수에 직접 접근하면 안된다!
		
		m1.setName("짜장면");
		m1.setPrice(8000);
		m1.setRecipe("1. 양파를 다진다. 2. 고기를 다진다. 3.양파를 볶는다. ...");
}
