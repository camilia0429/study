package test;

public class Ex07 {
	public static void main(String[] args) {
		// 변수는 선언만하고 데이터를 저장하지 않으면 사용할 수 없음
		int number;
		System.out.println(number);
		
		// 객체는 선언만하고 정보를 저장하지 않아도 멤버 변수를 사용할 수 있음
		Person p = new Person();
		
		System.out.println(p.name);
		System.out.println(p.age);
		System.out.println(p.height);
	}
	
}	
