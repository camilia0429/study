package test;

public class Ex03 {
	public static void main(String[] args) {
		Person p1 = new Person();
		Person p2 = new Person();
		Person p3 = new Person();
		
		p1.name = "김철수";
		p1.age = 21;
		p1.height = 170.5;
		p1.address = "인천광역시";
		
		p1.savePersonInformation("김철수", 21, 170.5, "인천광역시");
		p2.savePersonInformation("고영희", 22, 168.9, "서울특별시");
		p3.savePersonInformation("홍길동", 23, 171.6, "부산광역시");
		
		// p1이 가지고 있는 사람의 정보 출력
		p1.printPersonInformation();
		
		// p2가 가지고 있는 사람의 정보 출력
		p2.printPersonInformation();
		
		// p3가 가지고 있는 사람의 정보 출력
		p3.printPersonInformation();
		
	}
}
