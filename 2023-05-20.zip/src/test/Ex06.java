package test;

public class Ex06 {
	public static void main(String[] args) {
		// 세 자동차의 정보를 저장
		
		Car car1 = new Car("현대자동차", 1, "승용차");
		
		Car car2 = new Car("기아자동차", 7, "SUV");

		Car car3 = new Car("쌍용자동차", 4, "경차");
		
		System.out.println(car1.getBrand());
		System.out.println(car1.getColor());
		System.out.println(car1.getType());
		
		System.out.println(car2.getBrand());
		System.out.println(car2.getColor());
		System.out.println(car2.getType());
		
		System.out.println(car3.getBrand());
		System.out.println(car3.getColor());
		System.out.println(car3.getType());
	}
}
