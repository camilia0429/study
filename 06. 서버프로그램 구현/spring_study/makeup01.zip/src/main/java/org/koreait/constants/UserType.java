package org.koreait.constants;

public enum UserType {
    MEMBER,
    ADMIN
}
