package org.koreait.entities;


import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
@EqualsAndHashCode
@NoArgsConstructor @AllArgsConstructor
public class BoardViewId {
    private Long id;
    private Integer uid;

}
